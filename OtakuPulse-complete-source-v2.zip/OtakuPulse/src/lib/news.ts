import hero from "@/assets/hero.jpg";
import manga from "@/assets/manga.jpg";
import idol from "@/assets/idol.jpg";
import mecha from "@/assets/mecha.jpg";

export type Category = "anime" | "manga";
export type Article = {
  slug: string;
  title: string;
  excerpt: string;
  body: string[];
  category: Category;
  tag: string;
  image: string;
  date: string;
  author: string;
  sourceUrl?: string | undefined;
  isSpecial?: boolean;
  views?: number;
  live?: boolean;
  imageAlt?: string | undefined;
  seoTitle?: string | undefined;
  seoDescription?: string | undefined;
};

export const articles: Article[] = [
  {
    slug: "midnight-blade-season-2-announced",
    title: "Midnight Blade Season 2 Officially Announced for Spring 2027",
    excerpt: "The neon-soaked samurai saga returns with a new studio trailer and a returning cast.",
    body: [
      "The production committee confirmed today that Midnight Blade will return for a second season in Spring 2027.",
      "A teaser trailer revealed new character designs, and the original voice cast is set to return.",
      "Fans can expect the new arc to adapt volumes 6 through 10 of the original manga.",
    ],
    category: "anime",
    tag: "Announcement",
    image: hero,
    date: "Oct 21, 2026",
    author: "Ritesh Kirar",
  },
  {
    slug: "shadow-ink-manga-final-arc",
    title: "Shadow Ink Manga Enters Its Final Arc",
    excerpt: "The best-selling dark fantasy series will conclude within the next year, says the author.",
    body: [
      "In a note published in this week's magazine issue, the author revealed that Shadow Ink has entered its final arc.",
      "The series has sold more than 20 million copies worldwide since its debut.",
    ],
    category: "manga",
    tag: "Manga",
    image: manga,
    date: "Oct 20, 2026",
    author: "Ritesh Kirar",
  },
  {
    slug: "star-idol-movie-box-office",
    title: "Star Idol Movie Tops the Japanese Box Office",
    excerpt: "The idol film earned record numbers in its opening weekend.",
    body: ["The Star Idol movie opened at number one, beating every other film this weekend.", "An international release is planned for early next year."],
    category: "anime",
    tag: "Box Office",
    image: idol,
    date: "Oct 19, 2026",
    author: "Ritesh Kirar",
  },
  {
    slug: "iron-titan-reboot-studio",
    title: "Iron Titan Mecha Reboot Gets New Studio and Director",
    excerpt: "The classic giant robot franchise is coming back with a modern twist.",
    body: ["A reboot of the classic mecha series has been greenlit with a fresh creative team.", "More details will be revealed at next month's anime expo."],
    category: "anime",
    tag: "Production",
    image: mecha,
    date: "Oct 18, 2026",
    author: "Ritesh Kirar",
  },
  {
    slug: "new-manga-awards-2026",
    title: "Manga Awards 2026: Full List of Nominees Revealed",
    excerpt: "Ten series compete for this year's grand prize.",
    body: ["The nominees for the 2026 Manga Awards have been revealed.", "Winners will be announced in December."],
    category: "manga",
    tag: "Awards",
    image: manga,
    date: "Oct 17, 2026",
    author: "Ritesh Kirar",
  },
];

export const getArticle = (slug: string) => articles.find((a) => a.slug === slug);
