import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export function newsPublicClient() {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) throw new Error("News service unavailable.");
  return createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { fetch: (input, init) => {
      const headers = new Headers(init?.headers);
      if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
      headers.set("apikey", key);
      return fetch(input, { ...init, headers });
    } },
  });
}

export async function visibleNewsRows() {
  const client = newsPublicClient();
  const rows: Database["public"]["Tables"]["news_articles"]["Row"][] = [];
  for (let offset = 0; ; offset += 500) {
    const result = await client.from("news_articles").select("*").order("published_at", { ascending: false }).order("id").range(offset, offset + 499);
    if (result.error) throw new Error("Published news could not be loaded.");
    rows.push(...result.data);
    if (result.data.length < 500) return rows;
  }
}