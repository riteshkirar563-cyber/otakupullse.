import { z } from "zod";
import { DEFAULT_ARTICLE_AUTHOR } from "@/lib/editorial";

export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
export const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
export const editorSchema = z.object({
  title: z.string().max(250), excerpt: z.string().max(1000), body: z.string().max(100000),
  category: z.enum(["anime", "manga"]), tag: z.string().max(150), author: z.string().max(120),
  slug: z.string().max(200), image: z.string().max(2000), image_path: z.string().nullable(),
  image_alt: z.string().max(300), source: z.string().max(200), source_url: z.string().max(2000),
  is_special: z.boolean(), seo_title: z.string().max(250), seo_description: z.string().max(1000),
  scheduled_at: z.string(),
});
export type EditorValues = z.infer<typeof editorSchema>;
export const emptyEditor: EditorValues = {
  title: "", excerpt: "", body: "", category: "anime", tag: "News", author: DEFAULT_ARTICLE_AUTHOR,
  slug: "", image: "", image_path: null, image_alt: "", source: "", source_url: "", is_special: false,
  seo_title: "", seo_description: "", scheduled_at: "",
};
export function makeSlug(title: string) {
  return title.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 180).replace(/-$/g, "");
}
export function safeHttpUrl(value: string) {
  if (!value.trim()) return true;
  try { return new URL(value).protocol === "https:"; } catch { return false; }
}
export function validatePublication(values: EditorValues, status: string, now = Date.now()) {
  editorSchema.parse(values);
  if (status !== "draft" && (!values.title.trim() || !values.body.trim())) throw new Error("Title aur article body zaroori hain.");
  if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(values.slug)) throw new Error("Slug mein sirf lowercase letters, numbers aur hyphens rakhiye.");
  if (!safeHttpUrl(values.image) || !safeHttpUrl(values.source_url)) throw new Error("Photo aur source links valid HTTPS links hone chahiye.");
  if (status === "scheduled" && (!values.scheduled_at || !Number.isFinite(Date.parse(values.scheduled_at)) || Date.parse(values.scheduled_at) <= now)) throw new Error("Schedule ke liye future date aur time chuniye.");
}
export function imageValidation(file: Pick<File, "size" | "type">) {
  if (!IMAGE_TYPES.includes(file.type)) return "Sirf JPG, PNG ya WebP photo upload karein.";
  if (file.size === 0 || file.size > MAX_IMAGE_BYTES) return "Photo 5 MB ya usse chhoti honi chahiye.";
  return null;
}
export function isEnglishNews(title: string, summary: string) {
  const text = `${title} ${summary}`;
  if (/[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uac00-\ud7af\u0400-\u04ff\u0600-\u06ff\u0900-\u097f]/u.test(text)) return false;
  return /[a-zA-Z]/.test(title);
}
export function publiclyVisible(status: string, scheduledAt: string | null, now = Date.now()) {
  return status === "published" || (status === "scheduled" && scheduledAt !== null && Date.parse(scheduledAt) <= now);
}