// Edit this list to change the Anime List section.
// Add a category, or add/remove anime inside one — the front page and /anime-list both read this file.
export type ListAnime = { title: string; year: number; why: string };
export type AnimeListCategory = { category: string; emoji: string; anime: ListAnime[] };

export const animeLists: AnimeListCategory[] = [
  {
    category: "Action",
    emoji: "⚔️",
    anime: [
      { title: "Attack on Titan", year: 2013, why: "Humanity fights giants behind huge walls." },
      { title: "Jujutsu Kaisen", year: 2020, why: "Cursed spirits, slick fights, great school cast." },
      { title: "Demon Slayer", year: 2019, why: "Stunning animation, one brother's quest." },
      { title: "Hunter x Hunter", year: 2011, why: "The best adventure-to-battle climb in anime." },
      { title: "Chainsaw Man", year: 2022, why: "Filthy, funny and brutal demon hunting." },
      { title: "Vinland Saga", year: 2019, why: "Vikings, revenge and a real change of heart." },
    ],
  },
  {
    category: "Adventure",
    emoji: "🗺️",
    anime: [
      { title: "One Piece", year: 1999, why: "The long pirate road to the biggest treasure." },
      { title: "Fullmetal Alchemist: Brotherhood", year: 2009, why: "Perfect story, alchemy and brotherhood." },
      { title: "Frieren: Beyond Journey's End", year: 2023, why: "A quiet, beautiful trip after the quest ends." },
      { title: "Made in Abyss", year: 2017, why: "Cute look, terrifying deep hole." },
      { title: "Magi: The Labyrinth of Magic", year: 2012, why: "Dungeons, djinns and kingdom politics." },
      { title: "The Promised Neverland", year: 2018, why: "Kids escape a very wrong orphanage." },
    ],
  },
  {
    category: "Fantasy",
    emoji: "🐉",
    anime: [
      { title: "That Time I Got Reincarnated as a Slime", year: 2018, why: "A slime builds a monster nation." },
      { title: "Mushoku Tensei: Jobless Reincarnation", year: 2021, why: "Lifelong magic growth in a huge world." },
      { title: "Re:Zero − Starting Life in Another World", year: 2016, why: "Dies, rewinds, suffers, tries again." },
      { title: "Overlord", year: 2015, why: "A player stays as the biggest skeleton villain." },
      { title: "The Rising of the Shield Hero", year: 2019, why: "The weakest hero proves everyone wrong." },
      { title: "Durarara!!", year: 2010, why: "Ikebukuro street chaos with a headless rider." },
    ],
  },
  {
    category: "Romance",
    emoji: "💖",
    anime: [
      { title: "Your Lie in April", year: 2014, why: "Music, loss and first love. Bring tissues." },
      { title: "Horimiya", year: 2021, why: "Two secret sides fall for each other." },
      { title: "Kaguya-sama: Love is War", year: 2019, why: "Geniuses too proud to say \"I like you\"." },
      { title: "Toradora!", year: 2008, why: "Tiny tiger girl and gentle giant, slow burn." },
      { title: "Fruits Basket", year: 2019, why: "Warm, healing, and quietly heartbreaking." },
      { title: "My Dress-Up Darling", year: 2023, why: "Doll-maker and cosplayer, very sweet." },
    ],
  },
  {
    category: "Comedy",
    emoji: "😂",
    anime: [
      { title: "Gintama", year: 2006, why: "Jokes every 10 seconds, then it makes you cry." },
      { title: "Spy x Family", year: 2022, why: "Spy, assassin and telepath fake family." },
      { title: "KonoSuba", year: 2016, why: "The worst party ever assembled, somehow." },
      { title: "The Disastrous Life of Saiki K.", year: 2016, why: "All-powerful psychic just wants peace." },
      { title: "Grand Blue", year: 2018, why: "College diving club, mostly beer and shame." },
      { title: "One Punch Man", year: 2015, why: "A hero bored because he wins instantly." },
    ],
  },
  {
    category: "Mystery & Thriller",
    emoji: "🕵️",
    anime: [
      { title: "Death Note", year: 2006, why: "A notebook that kills, and two geniuses." },
      { title: "Monster", year: 2004, why: "A doctor chases the patient he saved." },
      { title: "Steins;Gate", year: 2011, why: "Time travel with a very high price." },
      { title: "Psycho-Pass", year: 2012, why: "Police read your crime before you do it." },
      { title: "Erased", year: 2015, why: "Goes back to childhood to stop a murder." },
      { title: "Parasyte: The Maxim", year: 2014, why: "Aliens take hands, not heads." },
    ],
  },
  {
    category: "Sci-Fi",
    emoji: "🚀",
    anime: [
      { title: "Cowboy Bebop", year: 1998, why: "Jazz, bounty hunters, perfect style." },
      { title: "Neon Genesis Evangelion", year: 1995, why: "Mecha that gets inside your head." },
      { title: "Ghost in the Shell: Stand Alone Complex", year: 2002, why: "Cyber crime in a wired future." },
      { title: "Code Geass: Lelouch of the Rebellion", year: 2006, why: "One command, one empire, endless chess." },
      { title: "Pluto", year: 2023, why: "Who is killing the world's best robots?" },
      { title: "86", year: 2021, why: "Drones with humans inside them." },
    ],
  },
  {
    category: "Sports",
    emoji: "🏀",
    anime: [
      { title: "Haikyu!!", year: 2014, why: "Short kid, huge volleyball dream." },
      { title: "Kuroko's Basketball", year: 2012, why: "Impossible passes, bigger egos." },
      { title: "Slam Dunk", year: 1993, why: "The classic that made everyone play basketball." },
      { title: "Blue Lock", year: 2022, why: "300 strikers, one ego-driven winner." },
      { title: "Hajime no Ippo", year: 2000, why: "Shy boy becomes a boxer. Pure fire." },
      { title: "The Prince of Tennis", year: 2001, why: "Cool shots, cold confidence." },
    ],
  },
  {
    category: "Slice of Life",
    emoji: "🍵",
    anime: [
      { title: "K-On!", year: 2009, why: "Girls, tea, guitars, almost nothing else." },
      { title: "Barakamon", year: 2014, why: "A calligrapher learns to slow down." },
      { title: "Laid-Back Camp", year: 2018, why: "Camping, hot springs and soft views." },
      { title: "Non Non Biyori", year: 2013, why: " countryside kids with endless time." },
      { title: "Aria The Animation", year: 2005, why: "Gondola rides on a water Mars." },
      { title: "Keep Your Hands Off Eizouken!", year: 2020, why: "Three girls build their own anime." },
    ],
  },
  {
    category: "Horror",
    emoji: "🩸",
    anime: [
      { title: "Another", year: 2012, why: "A class where someone should not exist." },
      { title: "Higurashi: When They Cry", year: 2006, why: "Cute village, very bad loop." },
      { title: "Devilman Crybaby", year: 2018, why: "Loud, wild and devastating." },
      { title: "Berserk", year: 1997, why: "Dark swordsman epic with a real betrayal." },
      { title: "Mononoke", year: 2007, why: "Painted spirits and a strange medicine seller." },
      { title: "Yami Shibai", year: 2013, why: "Five-minute Japanese ghost stories." },
    ],
  },
];
