// Edit this list to change the Anime Suggestions corner.
export type Suggestion = { title: string; why: string };
export type SuggestionCategory = { category: string; emoji: string; best: Suggestion; alsoWatch: Suggestion[] };

export const suggestionCategories: SuggestionCategory[] = [
  {
    category: "Action",
    emoji: "⚔️",
    best: { title: "Attack on Titan", why: "Epic story, huge battles and shocking twists." },
    alsoWatch: [
      { title: "Jujutsu Kaisen", why: "Stylish curse fights." },
      { title: "Demon Slayer", why: "Beautiful animation." },
    ],
  },
  {
    category: "Romance",
    emoji: "💖",
    best: { title: "Your Lie in April", why: "Emotional story about music and love." },
    alsoWatch: [
      { title: "Kaguya-sama: Love is War", why: "Funny love battle." },
      { title: "Horimiya", why: "Sweet school romance." },
    ],
  },
  {
    category: "Comedy",
    emoji: "😂",
    best: { title: "Gintama", why: "Non-stop jokes with great action." },
    alsoWatch: [
      { title: "Spy x Family", why: "Fun fake family." },
      { title: "One Punch Man", why: "Hero who wins with one punch." },
    ],
  },
  {
    category: "Mystery & Thriller",
    emoji: "🕵️",
    best: { title: "Death Note", why: "Genius mind games between two rivals." },
    alsoWatch: [
      { title: "Monster", why: "Dark and gripping." },
      { title: "Steins;Gate", why: "Time travel puzzle." },
    ],
  },
];
