export const SITE_URL = "https://otakupullse.lovable.app";
export const PUBLISHER_ID = "ca-pub-8522718655262490";
export const PUBLIC_PATHS = ["/", "/anime", "/manga", "/anime-list", "/suggestions", "/search", "/auth"];

export function pageHead(title: string, description: string, path: string, noindex = false) {
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: `${SITE_URL}${path}` },
      { name: "twitter:card", content: "summary_large_image" },
      ...(noindex ? [{ name: "robots", content: "noindex, nofollow" }] : []),
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}${path}` }],
  };
}