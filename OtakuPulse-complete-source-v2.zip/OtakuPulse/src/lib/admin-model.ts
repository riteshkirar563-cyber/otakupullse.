import type { Tables } from "@/integrations/supabase/types";

export type ArticleRow = Tables<"news_articles">;
export function filterArticles(rows: ArticleRow[], search: string, status: string, category: string, sort: string) {
  const term = search.trim().toLowerCase();
  return rows.filter(a => (!term || `${a.title} ${a.author} ${a.slug}`.toLowerCase().includes(term)) && (status === "all" || a.status === status) && (category === "all" || a.category === category)).sort((a, b) => sort === "views" ? b.views - a.views : sort === "title" ? a.title.localeCompare(b.title) : Date.parse(b.updated_at) - Date.parse(a.updated_at));
}
export function articleChecks(a: Pick<ArticleRow, "title" | "excerpt" | "body" | "image" | "image_path" | "image_alt" | "source_url" | "seo_title" | "seo_description">) {
  return [
    { label: "Title", ok: !!a.title.trim() },
    { label: "Summary", ok: !!a.excerpt.trim() },
    { label: "Article body", ok: a.body.some(p => !!p.trim()) },
    { label: "Cover image", ok: !!(a.image || a.image_path) },
    { label: "Image description", ok: !!a.image_alt?.trim() },
    { label: "Source attribution", ok: !!a.source_url },
    { label: "SEO title", ok: !!a.seo_title?.trim() },
    { label: "SEO description", ok: !!a.seo_description?.trim() },
  ];
}