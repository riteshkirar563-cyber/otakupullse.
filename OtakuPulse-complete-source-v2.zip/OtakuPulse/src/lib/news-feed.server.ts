export const FEEDS = [
  { source: "MyAnimeList", url: "https://myanimelist.net/rss/news.xml" },
  { source: "Anime Corner", url: "https://animecorner.me/feed/" },
  { source: "Crunchyroll", url: "https://cr-news-api-service.prd.crunchyrollsvc.com/v1/en-US/rss" },
] as const;

export type FeedItem = { source: string; link: string; title: string; summary: string; image: string | null; pubDate: string };

function decode(s: string) {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&#0?39;|&apos;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&amp;/g, "&")
    .trim();
}
const strip = (s: string) => decode(decode(s).replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
const tag = (xml: string, name: string) => xml.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`))?.[1] ?? "";

export function parseRss(xml: string, source: string): FeedItem[] {
  return [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)]
    .map((m) => {
      const it = m[1] ?? "";
      const raw = decode(tag(it, "content:encoded") || tag(it, "description"));
      const desc = strip(tag(it, "description")) || strip(raw);
      const image =
        it.match(/<media:thumbnail[^>]*>([^<]+)<\/media:thumbnail>/)?.[1] ??
        it.match(/<media:(?:thumbnail|content)[^>]*url="([^"]+)"/)?.[1] ??
        it.match(/<enclosure[^>]*url="([^"]+)"/)?.[1] ??
        raw.match(/<img[^>]*src="([^"]+)"/)?.[1] ??
        null;
      return {
        source,
        link: decode(tag(it, "link")).split("?_location")[0]!,
        title: strip(tag(it, "title")),
        summary: desc.slice(0, 2000),
        image: image ? decode(image) : null,
        pubDate: decode(tag(it, "pubDate")),
      };
    })
    .filter((i) => i.link && i.title);
}
