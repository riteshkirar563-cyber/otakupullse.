export const DEFAULT_ARTICLE_AUTHOR = "Otaku pulse";

export function articleAuthor(value: string): string {
  return value.trim() || DEFAULT_ARTICLE_AUTHOR;
}