import { queryOptions } from "@tanstack/react-query";
import { articles } from "@/lib/news";
import { listLiveNews, getLiveArticle } from "@/lib/news.functions";
import hero from "@/assets/hero.jpg";

export const allNewsQuery = queryOptions({
  queryKey: ["news", "all"],
  queryFn: async () => {
    const live = await listLiveNews({ data: { fallbackImage: hero } }).catch(() => []);
    return [...live, ...articles.filter(a => !live.some(l => l.slug === a.slug))];
  },
  staleTime: 60_000,
});

export const articleQuery = (slug: string) =>
  queryOptions({
    queryKey: ["news", "one", slug],
    queryFn: async () => (await getLiveArticle({ data: { slug, fallbackImage: hero } })) ?? articles.find((a) => a.slug === slug),
  });

