import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const adminDataQuery = queryOptions({
  queryKey: ["admin", "workspace"],
  queryFn: async () => {
    const [articles, inbox, comments, drafts] = await Promise.all([
      supabase.from("news_articles").select("*").order("published_at", { ascending: false }),
      supabase.from("news_inbox").select("*").order("published_at", { ascending: false }).limit(500),
      supabase.from("comments").select("id", { count: "exact", head: true }),
      supabase.from("article_workspaces").select("id,article_id,snapshot,updated_at").order("updated_at", { ascending: false }),
    ]);
    for (const result of [articles, inbox, comments, drafts]) if (result.error) throw new Error(result.error.message);
    return { articles: articles.data ?? [], inbox: inbox.data ?? [], comments: comments.count ?? 0, drafts: drafts.data ?? [] };
  },
  staleTime: 15000,
});