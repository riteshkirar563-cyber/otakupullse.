import { createServerFn } from "@tanstack/react-start";
import type { Database } from "@/integrations/supabase/types";
import type { Article } from "@/lib/news";
import { publiclyVisible } from "@/lib/editor-model";

type Row = Database["public"]["Tables"]["news_articles"]["Row"];
const toArticle = (r: Row, fallbackImage: string): Article => ({
  slug: r.slug,
  title: r.title,
  excerpt: r.excerpt,
  body: r.body,
  category: r.category === "manga" ? "manga" : "anime",
  tag: r.tag,
  image: r.image_path ? `/api/public/article-image/${r.id}` : r.image || fallbackImage,
  date: new Date(r.published_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
  author: r.author,
  sourceUrl: r.source_url ?? undefined,
  isSpecial: r.is_special,
  views: r.views,
  live: true,
  imageAlt: r.image_alt ?? undefined,
  seoTitle: r.seo_title ?? undefined,
  seoDescription: r.seo_description ?? undefined,
});

export const listLiveNews = createServerFn({ method: "GET" })
  .inputValidator((d: { fallbackImage: string }) => d)
  .handler(async ({ data }) => {
    const { newsPublicClient } = await import("@/lib/news-public.server");
    const client = newsPublicClient();
    const { data: rows, error } = await client.from("news_articles").select("*").order("published_at", { ascending: false });
    if (error) throw new Error("Published news could not be loaded.");
    return (rows ?? []).filter(r => publiclyVisible(r.status, r.scheduled_at)).map((r) => toArticle(r, data.fallbackImage));
  });

export const getLiveArticle = createServerFn({ method: "GET" })
  .inputValidator((d: { slug: string; fallbackImage: string }) => d)
  .handler(async ({ data }) => {
    const { newsPublicClient } = await import("@/lib/news-public.server");
    const client = newsPublicClient();
    const { data: row, error } = await client.from("news_articles").select("*").eq("slug", data.slug).maybeSingle();
    if (error) throw new Error("Article could not be loaded.");
    if (row && publiclyVisible(row.status, row.scheduled_at)) return toArticle(row, data.fallbackImage);
    const { data: alias } = await client.from("article_slug_aliases").select("article_id").eq("old_slug", data.slug).maybeSingle();
    if (!alias) return null;
    const { data: target } = await client.from("news_articles").select("*").eq("id", alias.article_id).maybeSingle();
    return target && publiclyVisible(target.status, target.scheduled_at) ? toArticle(target, data.fallbackImage) : null;
  });

export const countView = createServerFn({ method: "POST" })
  .inputValidator((d: { slug: string }) => ({ slug: String(d.slug).slice(0, 200) }))
  .handler(async ({ data }) => {
    const { newsPublicClient } = await import("@/lib/news-public.server");
    const { error } = await newsPublicClient().rpc("increment_article_views", { _slug: data.slug });
    if (error) throw new Error("View count could not be saved.");
    return { ok: true };
  });

