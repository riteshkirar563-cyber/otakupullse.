import { describe, expect, it } from "vitest";
import { emptyEditor, imageValidation, isEnglishNews, validatePublication, publiclyVisible } from "@/lib/editor-model";
describe("Editorial rules", () => {
  it("keeps new articles attributed to Otaku pulse", () => { expect(emptyEditor.author).toBe("Otaku pulse"); });
  it("rejects Japanese and Chinese incoming news", () => { expect(isEnglishNews("アニメ news", "Trailer")).toBe(false); expect(isEnglishNews("Anime news", "新作")).toBe(false); expect(isEnglishNews("Anime trailer announced", "New season")).toBe(true); });
  it("does not expose drafts or future schedules", () => { expect(publiclyVisible("draft", null, 1000)).toBe(false); expect(publiclyVisible("scheduled", "2027-01-01T00:00:00Z", 1000)).toBe(false); expect(publiclyVisible("published", null, 1000)).toBe(true); });
  it("allows only JPG PNG WebP up to 5 MB", () => { expect(imageValidation({ type: "image/jpeg", size: 5 * 1024 * 1024 })).toBe(null); expect(imageValidation({ type: "image/png", size: 5 * 1024 * 1024 + 1 })).not.toBe(null); expect(imageValidation({ type: "image/svg+xml", size: 100 })).not.toBe(null); });
  it("requires a manually written title and body before publication", () => { expect(() => validatePublication({ ...emptyEditor, slug: "article" }, "published")).toThrow(); expect(() => validatePublication({ ...emptyEditor, title: "Article", body: "Written manually", slug: "article" }, "published")).not.toThrow(); });
});