import { describe, expect, it } from "vitest";
import { articleAuthor, DEFAULT_ARTICLE_AUTHOR } from "@/lib/editorial";

describe("Article author", () => {
  it("defaults new and blank article authors to Otaku pulse", () => {
    expect(DEFAULT_ARTICLE_AUTHOR).toBe("Otaku pulse");
    expect(articleAuthor("  ")).toBe("Otaku pulse");
  });

  it("preserves an explicitly entered author", () => {
    expect(articleAuthor(" Guest writer ")).toBe("Guest writer");
  });
});