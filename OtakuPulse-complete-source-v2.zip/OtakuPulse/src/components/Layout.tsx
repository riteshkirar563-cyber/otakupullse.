import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import type { Article } from "@/lib/news";
import { Button } from "@/components/ui/button";

function MoreMenu() {
  const { user, isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const item = "block px-4 py-2 font-display text-lg tracking-wide text-muted-foreground hover:bg-secondary hover:text-primary";
  return (
    <div className="relative">
      <Button variant="ghost" size="icon" aria-label="More" aria-expanded={open} onClick={() => setOpen((o) => !o)} className="text-2xl">⋮</Button>
      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="animate-fade-up absolute right-0 z-40 mt-2 w-40 overflow-hidden rounded-lg border border-border bg-popover shadow-lg" onClick={() => setOpen(false)}>
            <Link to="/anime-list" className={item}>List</Link>
            {isAdmin && <Link to="/admin" search={{ tab: "overview" }} className={item}>Desk</Link>}
            {!user && <Link to="/auth" search={{}} className={item}>Login</Link>}
            {user && <button className={`${item} w-full text-left`} onClick={() => supabase.auth.signOut()}>Logout</button>}
          </div>
        </>
      )}
    </div>
  );
}

export function Header() {
  const link = "font-display text-lg tracking-wide text-muted-foreground hover:text-primary transition-colors";
  return (
    <header className="sticky top-0 z-20 border-b border-border bg-background/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-4 gap-y-1 px-4 py-3">
        <Link to="/" className="font-display text-3xl tracking-wider text-foreground">
          OTAKU<span className="text-shimmer">PULSE</span>
        </Link>
        <nav className="flex items-center gap-3 whitespace-nowrap">
          <Link to="/anime" className={link} activeProps={{ className: "text-primary" }}>Anime</Link>
          <Link to="/manga" className={link} activeProps={{ className: "text-primary" }}>Manga</Link>
          <Link to="/suggestions" className={link} activeProps={{ className: "text-primary" }}>Picks</Link>
          <Link to="/search" search={{ q: "" }} aria-label="Search" className="text-xl text-muted-foreground hover:text-primary">⌕</Link>
          <MoreMenu />
        </nav>
      </div>
    </header>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="animate-page mx-auto max-w-6xl px-4 py-8">{children}</main>
      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">
        <nav aria-label="Site information" className="mb-4 flex flex-wrap justify-center gap-4 px-4">
          <Link to="/about">About</Link><Link to="/privacy">Privacy</Link><Link to="/terms">Terms</Link><Link to="/editorial-policy">Editorial policy</Link>
        </nav>
        © 2026 OtakuPulse — Anime & Manga News
      </footer>
    </div>
  );
}

export function ArticleCard({ a }: { a: Article }) {
  return (
    <Link to="/news/$slug" params={{ slug: a.slug }} className="reveal lift group block overflow-hidden rounded-lg border border-border bg-card hover:border-primary">
      <div className="aspect-video overflow-hidden">
        <img src={a.image} alt={a.title} loading="lazy" width={1200} height={800} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
      </div>
      <div className="p-4">
        <span className="text-xs font-bold uppercase tracking-widest text-primary">{a.tag}</span>
        {!a.live && <p className="mt-1 text-xs text-muted-foreground">Legacy sample · Unverified</p>}
        <h3 className="mt-1 text-lg font-semibold leading-snug group-hover:text-primary">{a.title}</h3>
        <p className="mt-2 text-xs text-muted-foreground">{a.date}</p>
      </div>
    </Link>
  );
}
