import { Shell } from "@/components/Layout";
import type { ReactNode } from "react";

export function PolicyPage({ title, children }: { title: string; children: ReactNode }) {
  return <Shell><article className="mx-auto max-w-3xl"><p className="text-sm font-semibold text-primary">OTAKUPULSE</p><h1 className="mt-2 font-display text-5xl">{title}</h1><div className="mt-8 space-y-6 text-base leading-relaxed text-muted-foreground">{children}</div></article></Shell>;
}