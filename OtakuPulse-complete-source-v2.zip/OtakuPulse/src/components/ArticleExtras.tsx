import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, displayName } from "@/hooks/use-auth";
import { countView } from "@/lib/news.functions";

export function ShareButtons({ title }: { title: string }) {
  const [url, setUrl] = useState("");
  const [copied, setCopied] = useState(false);
  useEffect(() => setUrl(window.location.href), []);
  const u = encodeURIComponent(url);
  const t = encodeURIComponent(title);
  const btn = "lift rounded-md border border-border bg-card px-3 py-2 text-sm font-semibold hover:border-primary hover:text-primary";
  return (
    <div className="mt-8 flex flex-wrap items-center gap-2">
      <span className="mr-1 text-xs font-bold uppercase tracking-widest text-muted-foreground">Share</span>
      <a className={btn} target="_blank" rel="noopener noreferrer" href={`https://wa.me/?text=${t}%20${u}`}>WhatsApp</a>
      <a className={btn} target="_blank" rel="noopener noreferrer" href={`https://twitter.com/intent/tweet?text=${t}&url=${u}`}>X</a>
      <a className={btn} target="_blank" rel="noopener noreferrer" href={`https://www.facebook.com/sharer/sharer.php?u=${u}`}>Facebook</a>
      <button className={btn} onClick={() => { navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>
        {copied ? "Copied!" : "Copy link"}
      </button>
    </div>
  );
}

export function ViewCounter({ slug }: { slug: string }) {
  useEffect(() => {
    const key = `op-viewed-${slug}`;
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, "1");
    countView({ data: { slug } }).catch(() => {});
  }, [slug]);
  return null;
}

export function Comments({ slug }: { slug: string }) {
  const { user, isAdmin } = useAuth();
  const qc = useQueryClient();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const key = ["comments", slug];
  const { data } = useQuery({
    queryKey: key,
    queryFn: async () => (await supabase.from("comments").select("*").eq("article_slug", slug).order("created_at", { ascending: true })).data ?? [],
  });
  const post = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !text.trim()) return;
    setBusy(true);
    await supabase.from("comments").insert({ article_slug: slug, user_id: user.id, user_name: displayName(user), body: text.trim().slice(0, 1000) });
    setText("");
    setBusy(false);
    qc.invalidateQueries({ queryKey: key });
  };
  const remove = async (id: string) => {
    await supabase.from("comments").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: key });
  };
  return (
    <section className="mt-12 border-t border-border pt-8">
      <h2 className="font-display text-3xl tracking-wide">Comments <span className="text-primary">({data?.length ?? 0})</span></h2>
      {user ? (
        <form onSubmit={post} className="mt-4 space-y-2">
          <textarea value={text} onChange={(e) => setText(e.target.value)} maxLength={1000} placeholder="Apni raay likhiye…" className="min-h-24 w-full rounded-md border border-input bg-background px-3 py-2" />
          <button disabled={busy || !text.trim()} className="rounded-md bg-primary px-4 py-2 font-semibold text-primary-foreground disabled:opacity-50">Post</button>
        </form>
      ) : (
        <Link to="/auth" search={{ next: `/news/${slug}` }} className="mt-4 inline-block rounded-md border border-primary px-4 py-2 font-semibold text-primary">
          Sign in with Google to comment
        </Link>
      )}
      <ul className="mt-6 space-y-4">
        {data?.map((c) => (
          <li key={c.id} className="animate-fade-up rounded-lg border border-border bg-card p-4">
            <div className="flex items-center justify-between">
              <p className="font-semibold text-primary">{c.user_name}</p>
              <p className="text-xs text-muted-foreground">{new Date(c.created_at).toLocaleDateString()}</p>
            </div>
            <p className="mt-1 whitespace-pre-wrap">{c.body}</p>
            {(c.user_id === user?.id || isAdmin) && (
              <button onClick={() => remove(c.id)} className="mt-2 text-xs text-muted-foreground hover:text-destructive">Delete</button>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
