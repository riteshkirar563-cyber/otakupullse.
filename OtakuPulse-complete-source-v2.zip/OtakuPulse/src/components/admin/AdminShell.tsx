import { Link } from "@tanstack/react-router";
import { LayoutDashboard, Newspaper, Inbox, ShieldCheck, BarChart3, PenLine, ArrowLeft, SearchCheck } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";

export type DeskTab = "overview" | "articles" | "inbox" | "seo" | "adsense" | "analytics";
const tabs = [
  { id: "overview", label: "Overview", icon: LayoutDashboard }, { id: "articles", label: "Articles", icon: Newspaper },
  { id: "inbox", label: "News inbox", icon: Inbox }, { id: "seo", label: "SEO health", icon: SearchCheck },
  { id: "adsense", label: "AdSense readiness", icon: ShieldCheck }, { id: "analytics", label: "Analytics", icon: BarChart3 },
] as const;
export function AdminShell({ children, tab, onTab, title, subtitle }: { children: ReactNode; tab?: DeskTab; onTab?: (tab: DeskTab) => void; title: string; subtitle: string }) {
  return <div className="admin-theme min-h-screen bg-background text-foreground">
    <header className="border-b border-border bg-card"><div className="mx-auto flex max-w-[1500px] items-center justify-between gap-4 px-4 py-4 md:px-8">
      <Link to="/" className="font-display text-3xl">OTAKU<span className="text-primary">PULSE</span><span className="ml-3 hidden align-middle font-sans text-xs font-semibold text-muted-foreground sm:inline">EDITORIAL DESK</span></Link>
      <Button asChild variant="ghost" size="sm"><Link to="/"><ArrowLeft /> Website</Link></Button>
    </div></header>
    <div className="mx-auto grid max-w-[1500px] lg:grid-cols-[220px_minmax(0,1fr)]">
      <aside className="border-b border-border px-3 py-4 lg:min-h-[calc(100vh-77px)] lg:border-r lg:border-b-0 lg:py-8">
        <nav aria-label="Editorial desk" className="flex gap-1 overflow-x-auto lg:flex-col">
          {tabs.map(({ id, label, icon: Icon }) => onTab ? <Button key={id} variant={tab === id ? "secondary" : "ghost"} aria-current={tab === id ? "page" : undefined} onClick={() => onTab(id)} className={`shrink-0 justify-start lg:w-full ${tab === id ? "text-primary" : "text-muted-foreground"}`}><Icon />{label}</Button> : <Button key={id} asChild variant="ghost" className="shrink-0 justify-start text-muted-foreground"><Link to="/admin" search={{ tab: id }}><Icon />{label}</Link></Button>)}
        </nav>
      </aside>
      <main className="min-w-0 px-4 py-6 md:px-8 md:py-8"><div className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div><p className="mb-2 text-xs font-semibold uppercase text-primary">OtakuPulse / News desk</p><h1 className="font-display text-4xl md:text-5xl">{title}</h1><p className="mt-2 text-sm text-muted-foreground">{subtitle}</p></div>
        {onTab && <Button asChild><Link to="/admin/write" search={{}}><PenLine />Write article</Link></Button>}
      </div>{children}</main>
    </div>
  </div>;
}