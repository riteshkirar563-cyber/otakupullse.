import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle2, AlertTriangle, RefreshCw } from "lucide-react";
import { PUBLISHER_ID } from "@/lib/site";
import { articleChecks, type ArticleRow } from "@/lib/admin-model";
import { articles as legacy } from "@/lib/news";

export function Readiness({ articles, mode }: { articles: ArticleRow[]; mode: "seo" | "adsense" }) {
  const [ads, setAds] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const inspect = async () => {
    setBusy(true); setError("");
    try {
      const response = await fetch("/ads.txt");
      if (!response.ok) throw new Error("ads.txt could not be loaded.");
      const text = await response.text();
      setAds(text.trim() === "google.com, pub-8522718655262490, DIRECT, f08c47fec0942fa0" ? "Publisher entry matches" : "Publisher entry needs checking");
    } catch (e) { setError(e instanceof Error ? e.message : "Check failed"); }
    finally { setBusy(false); }
  };
  const rows = articles.filter(a => a.status === "published");
  return <div className="space-y-8">
    {mode === "adsense" && <>
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-5"><div><h2 className="text-xl font-semibold">Publisher verification</h2><p className="mt-2 break-all text-sm text-muted-foreground">{PUBLISHER_ID}</p></div><Button variant="outline" disabled={busy} onClick={inspect}><RefreshCw />{busy ? "Checking…" : "Check ads.txt"}</Button></div>
      <p className="text-sm">Verification meta tag installed. Ad-serving script is disabled until consent requirements are addressed.</p>
      {ads && <p className="text-sm text-primary">{ads}</p>}{error && <p role="alert" className="text-destructive">{error}</p>}
      <ul className="space-y-3 text-sm text-muted-foreground"><li className="flex gap-2"><CheckCircle2 className="size-4 shrink-0 text-primary" />About, Privacy, Terms and editorial policy pages added.</li><li className="flex gap-2"><AlertTriangle className="size-4 shrink-0 text-accent" />Public contact details pending.</li><li className="flex gap-2"><AlertTriangle className="size-4 shrink-0 text-accent" />{legacy.length} legacy sample stories need source verification and replacement.</li><li className="flex gap-2"><AlertTriangle className="size-4 shrink-0 text-accent" />Image licenses and article originality require your editorial review.</li><li>Google approval, consent setup, ad delivery and revenue are not verified here. Publish changes, then request verification in your AdSense account using the meta-tag method.</li></ul>
    </>}
    <section><h2 className="text-xl font-semibold">Published article checks</h2><p className="mt-2 text-sm text-muted-foreground">{rows.length} published articles. Field completeness is not a verdict on content quality or Google approval.</p><ul className="mt-5 divide-y divide-border">{rows.map(a => <li key={a.id} className="py-4"><h3 className="font-semibold">{a.title}</h3><div className="mt-3 flex flex-wrap gap-x-5 gap-y-2">{articleChecks(a).map(c => <span key={c.label} className={`flex items-center gap-1 text-xs ${c.ok ? "text-primary" : "text-muted-foreground"}`}>{c.ok ? <CheckCircle2 className="size-3" /> : <AlertTriangle className="size-3" />}{c.label}</span>)}</div></li>)}</ul>{!rows.length && <p className="mt-6 text-muted-foreground">No published articles to inspect.</p>}</section>
  </div>;
}