import { pageHead } from "@/lib/site";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Shell, ArticleCard } from "@/components/Layout";
import { useSuspenseQuery } from "@tanstack/react-query";
import { allNewsQuery } from "@/lib/news-query";
import { suggestionCategories } from "@/lib/suggestions";
import { animeLists } from "@/lib/animeList";

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>) => ({ q: typeof s["q"] === "string" ? (s["q"] as string) : "" }),
  loader: ({ context }) => context.queryClient.ensureQueryData(allNewsQuery),
  head: () => pageHead("Search — OtakuPulse", "Search articles and curated anime selections.", "/search", true),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  const { data: articles } = useSuspenseQuery(allNewsQuery);
  const navigate = useNavigate({ from: "/search" });
  const term = q.trim().toLowerCase();
  const results = term
    ? articles.filter((a) => [a.title, a.excerpt, a.tag, a.category].join(" ").toLowerCase().includes(term))
    : [];
  const animeHits = term
    ? suggestionCategories.flatMap((c) => [c.best, ...c.alsoWatch].filter((s) => s.title.toLowerCase().includes(term)).map((s) => ({ ...s, cat: c.category })))
    : [];
  const listHits = term
    ? animeLists
        .flatMap((c) => c.anime.filter((a) => a.title.toLowerCase().includes(term)).map((a) => ({ ...a, cat: c.category })))
        .filter((a) => !animeHits.some((s) => s.title === a.title))
    : [];

  return (
    <Shell>
      <h1 className="font-display text-5xl tracking-wide">Search</h1>
      <input
        autoFocus
        value={q}
        onChange={(e) => navigate({ search: { q: e.target.value }, replace: true })}
        placeholder="Search anime, manga, news..."
        className="mt-4 w-full rounded-lg border border-input bg-card px-4 py-3 text-lg outline-none focus:border-primary"
      />
      {term && (
        <p className="mt-4 text-sm text-muted-foreground">{results.length + animeHits.length + listHits.length} results for "{q}"</p>
      )}
      {animeHits.length > 0 && (
        <ul className="mt-4 space-y-2">
          {animeHits.map((s) => (
            <li key={s.title} className="reveal lift rounded-lg border border-border bg-card p-3 text-sm">
              <span className="font-semibold">{s.title}</span> <span className="text-primary">· Suggested in {s.cat}</span>
            </li>
          ))}
        </ul>
      )}
      {listHits.length > 0 && (
        <ul className="mt-3 space-y-2">
          {listHits.map((a) => (
            <li key={a.title} className="reveal lift rounded-lg border border-border bg-card p-3 text-sm">
              <span className="font-semibold">{a.title}</span> <span className="text-xs text-muted-foreground">({a.year})</span>{" "}
              <span className="text-primary">· {a.cat} list</span> <span className="text-muted-foreground">— {a.why}</span>
            </li>
          ))}
        </ul>
      )}
      <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {results.map((a) => <ArticleCard key={a.slug} a={a} />)}
      </div>
    </Shell>
  );
}
