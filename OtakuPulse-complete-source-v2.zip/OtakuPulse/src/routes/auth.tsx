import { pageHead } from "@/lib/site";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Layout";
import { lovable } from "@/integrations/lovable";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { next?: string | undefined } => {
    const n = s["next"];
    return { next: typeof n === "string" && n.startsWith("/") && !n.startsWith("//") ? n : undefined };
  },
  head: () => pageHead("Sign in — OtakuPulse", "Sign in to comment and access your editorial workspace.", "/auth", true),
  component: AuthPage,
});

function AuthPage() {
  const { next } = Route.useSearch();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && user) {
      const saved = sessionStorage.getItem("op-next");
      sessionStorage.removeItem("op-next");
      const to = next ?? (saved && saved.startsWith("/") ? saved : "/");
      navigate({ to, replace: true });
    }
  }, [loading, user, next, navigate]);

  const signIn = async () => {
    setError(null);
    if (next) sessionStorage.setItem("op-next", next);
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/auth" });
    if (r.error) setError(r.error.message ?? "Sign in failed");
  };

  return (
    <Shell>
      <div className="animate-fade-up mx-auto mt-10 max-w-sm rounded-xl border border-border bg-card p-8 text-center">
        <h1 className="font-display text-4xl tracking-wide">Welcome <span className="text-primary">Otaku</span></h1>
        <p className="mt-2 text-sm text-muted-foreground">Sign in to comment on news.</p>
        <button onClick={signIn} className="lift mt-6 w-full rounded-md bg-primary px-4 py-3 font-semibold text-primary-foreground">
          Continue with Google
        </button>
        {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
      </div>
    </Shell>
  );
}
