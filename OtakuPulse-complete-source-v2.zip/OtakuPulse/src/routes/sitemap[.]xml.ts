import { createFileRoute } from "@tanstack/react-router";
import { SITE_URL } from "@/lib/site";
export const Route = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async () => {
  const { visibleNewsRows } = await import("@/lib/news-public.server");
  const rows = await visibleNewsRows();
  const paths = ["/", "/anime", "/manga", "/anime-list", "/suggestions", "/about", "/privacy", "/terms", "/editorial-policy", ...rows.map(a => `/news/${a.slug}`)];
  const escape = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
  return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${paths.map(p => `<url><loc>${escape(SITE_URL + p)}</loc></url>`).join('')}</urlset>`, { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
} } } });