import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/article-image/$id")({ server: { handlers: { GET: async ({ params }) => {
  if (!/^[0-9a-f-]{36}$/i.test(params.id)) return new Response("Not found", { status: 404 });
  const { newsPublicClient } = await import("@/lib/news-public.server");
  const client = newsPublicClient();
  const article = await client.from("news_articles").select("image_path").eq("id", params.id).maybeSingle();
  if (article.error) return new Response("Image unavailable", { status: 503 });
  if (!article.data?.image_path) return new Response("Not found", { status: 404 });
  const image = await client.storage.from("article-images").download(article.data.image_path);
  if (image.error || !image.data) return new Response("Not found", { status: 404 });
  if (!["image/jpeg", "image/png", "image/webp"].includes(image.data.type)) return new Response("Unsupported image", { status: 415 });
  return new Response(image.data, { headers: { "Content-Type": image.data.type, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
} } } });