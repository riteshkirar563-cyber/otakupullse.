import { createFileRoute } from "@tanstack/react-router";
import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";
import { isEnglishNews } from "@/lib/editor-model";

// Collects news from other sites into the private inbox. Nothing is published here.
export const Route = createFileRoute("/api/public/jobs/fetch-news")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authFailure = await authenticateCronRequest(request);
        if (authFailure) return authFailure;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { FEEDS, parseRss } = await import("@/lib/news-feed.server");

        const items = (
          await Promise.all(
            FEEDS.map(async (f) => {
              try {
                const res = await fetch(f.url, { headers: { "User-Agent": "Mozilla/5.0 (compatible; OtakuPulseBot/1.0)" } });
                return res.ok ? parseRss(await res.text(), f.source).slice(0, 30) : [];
              } catch {
                return [];
              }
            }),
          )
        ).flat()
          // Sirf English news: Japanese/Chinese characters wali items hatao
          .filter((i) => isEnglishNews(i.title, i.summary));

        const rows = items.map((i) => ({
          source: i.source,
          source_url: i.link,
          title: i.title,
          summary: i.summary,
          image: i.image,
          published_at: new Date(Date.parse(i.pubDate) || Date.now()).toISOString(),
        }));
        const { error, count } = await supabaseAdmin
          .from("news_inbox")
          .upsert(rows, { onConflict: "source_url", ignoreDuplicates: true, count: "exact" });
        return Response.json({ fetched: rows.length, added: count ?? 0, error: error?.message ?? null });
      },
    },
  },
});
