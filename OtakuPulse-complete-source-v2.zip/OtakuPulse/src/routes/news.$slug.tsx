import { createFileRoute, notFound, redirect } from "@tanstack/react-router";
import { Shell } from "@/components/Layout";
import { articleQuery } from "@/lib/news-query";
import { ShareButtons, ViewCounter, Comments } from "@/components/ArticleExtras";
import { pageHead, SITE_URL } from "@/lib/site";

export const Route = createFileRoute("/news/$slug")({
  loader: async ({ params, context }) => {
    const article = await context.queryClient.ensureQueryData(articleQuery(params.slug));
    if (!article) throw notFound();
    if (article.slug !== params.slug) throw redirect({ to: "/news/$slug", params: { slug: article.slug }, statusCode: 301 });
    return article;
  },
  head: ({ loaderData }) => {
    if (!loaderData) return pageHead("Article unavailable — OtakuPulse", "This article is unavailable.", "/news", true);
    const a = loaderData;
    const head = pageHead(`${a.seoTitle || a.title} — OtakuPulse`, a.seoDescription || a.excerpt, `/news/${a.slug}`, !a.live);
    const type = head.meta.find(m => m.property === "og:type");
    if (type) type.content = "article";
    if (a.image.startsWith("https://")) head.meta.push({ property: "og:image", content: a.image }, { name: "twitter:image", content: a.image });
    return { ...head, scripts: a.live ? [{ type: "application/ld+json", children: JSON.stringify({ "@context": "https://schema.org", "@type": "NewsArticle", headline: a.title, description: a.excerpt, author: { "@type": "Person", name: a.author }, mainEntityOfPage: `${SITE_URL}/news/${a.slug}`, ...(a.image.startsWith('https://') ? { image: a.image } : {}) }).replace(/</g, "\\u003c") }] : [] };
  },
  component: ArticlePage,
});

function ArticlePage() {
  const a = Route.useLoaderData();
  return (
    <Shell>
      <article className="animate-fade-up mx-auto max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-widest text-primary">{a.tag}</span>
        <h1 className="mt-2 font-display text-4xl leading-none tracking-wide md:text-6xl">{a.title}</h1>
        <p className="mt-3 text-sm text-muted-foreground">By {a.author} · {a.date}</p>
        {!a.live && <p className="mt-4 border-l-4 border-accent pl-3 text-sm text-muted-foreground">Legacy sample from the original website. This story has not been verified and must not be treated as factual reporting.</p>}
        <img src={a.image} alt={a.imageAlt || a.title} width={1200} height={800} className="mt-6 w-full rounded-xl object-cover" />
        <div className="mt-6 space-y-4 text-lg leading-relaxed">
          {a.body.map((p, i) => <p key={i}>{p}</p>)}
        </div>
        {a.sourceUrl && (
          <a href={a.sourceUrl} target="_blank" rel="noopener noreferrer" className="mt-8 inline-block text-sm font-semibold text-primary">Original source →</a>
        )}
        <ShareButtons title={a.title} />
        {a.live && <ViewCounter slug={a.slug} />}
        <Comments slug={a.slug} />
      </article>
    </Shell>
  );
}
