import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell, ArticleCard } from "@/components/Layout";
import { useSuspenseQuery } from "@tanstack/react-query";
import { allNewsQuery } from "@/lib/news-query";
import { suggestionCategories } from "@/lib/suggestions";
import { animeLists } from "@/lib/animeList";
import { pageHead } from "@/lib/site";

export const Route = createFileRoute("/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(allNewsQuery),
  head: ({ loaderData }) => {
    const head = pageHead("OtakuPulse — Anime & Manga News", "Manually edited anime and manga stories, watchlists and recommendations.", "/");
    const cover = (loaderData?.find(a => a.isSpecial) ?? loaderData?.[0])?.image;
    if (cover?.startsWith("https://")) head.meta.push({ property: "og:image", content: cover }, { name: "twitter:image", content: cover });
    return head;
  },
  component: Index,
});

function Index() {
  const { data: articles } = useSuspenseQuery(allNewsQuery);
  const special = articles.find((a) => a.isSpecial) ?? articles[0];
  if (!special) return <Shell><h1 className="font-display text-5xl">OtakuPulse</h1><p className="mt-4 text-muted-foreground">No published stories yet.</p></Shell>;
  const rest = articles.filter((a) => a.slug !== special.slug);
  const trending = articles.filter((a) => (a.views ?? 0) > 0).sort((a, b) => (b.views ?? 0) - (a.views ?? 0)).slice(0, 5);
  const today = new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });
  return (
    <Shell>
      <section className="special-frame animate-fade-up rounded-2xl p-[3px]">
        <div className="rounded-[calc(1rem-3px)] bg-background">
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3">
            <div className="flex items-center gap-2 font-display text-2xl tracking-widest md:text-3xl">
              <span className="live-dot" aria-hidden />
              <span className="text-shimmer">★ Today's Special</span>
            </div>
            <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{today}</span>
          </div>
          <Link to="/news/$slug" params={{ slug: special.slug }} className="group relative block overflow-hidden rounded-b-[calc(1rem-3px)]">
            <img src={special.image} alt={special.title} width={1600} height={912} className="animate-hero-zoom h-[440px] w-full object-cover transition duration-700 group-hover:scale-105 md:h-[560px]" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
            <div className="animate-fade-up absolute bottom-0 p-6 md:p-10" style={{ animationDelay: "0.25s" }}>
              <span className="animate-glow inline-block rounded-sm bg-primary px-2 py-0.5 text-xs font-bold uppercase tracking-widest text-primary-foreground">{special.tag}</span>
              {!special.live && <p className="mt-2 text-sm text-accent">Legacy sample · Unverified story</p>}
              <h1 className="mt-3 max-w-3xl font-display text-4xl leading-none tracking-wide md:text-7xl">{special.title}</h1>
              <p className="mt-3 max-w-xl text-muted-foreground">{special.excerpt}</p>
              <span className="mt-4 inline-block font-semibold text-primary transition group-hover:translate-x-2">Read the full story →</span>
            </div>
          </Link>
        </div>
      </section>

      {trending.length > 0 && (
        <section className="reveal mt-10">
          <h2 className="mb-4 border-l-4 border-primary pl-3 font-display text-3xl tracking-wide">🔥 Trending <span className="text-primary">Now</span></h2>
          <ol className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {trending.map((a, i) => (
              <li key={a.slug}>
                <Link to="/news/$slug" params={{ slug: a.slug }} className="lift block h-full rounded-lg border border-border bg-card p-3 hover:border-primary">
                  <span className="font-display text-4xl text-primary">#{i + 1}</span>
                  <p className="mt-1 font-semibold leading-snug">{a.title}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{a.views} reads</p>
                </Link>
              </li>
            ))}
          </ol>
        </section>
      )}

      <section className="reveal mt-10 rounded-xl border-2 border-primary bg-card p-5">
        <h2 className="font-display text-3xl tracking-wide">★ Today's Special <span className="text-primary">Corner</span></h2>
        <ul className="mt-4 divide-y divide-border">
          {rest.slice(0, 3).map((a, i) => (
            <li key={a.slug}>
              <Link to="/news/$slug" params={{ slug: a.slug }} className="flex items-center gap-3 py-3 transition-all duration-300 hover:translate-x-2 hover:text-primary">
                <span className="font-display text-3xl text-primary">0{i + 1}</span>
                <img src={a.image} alt="" loading="lazy" width={80} height={56} className="h-14 w-20 rounded object-cover" />
                <span className="font-semibold leading-snug">{a.title}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <h2 className="reveal mt-12 mb-5 border-l-4 border-primary pl-3 font-display text-3xl tracking-wide">Latest News</h2>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {rest.slice(0, 12).map((a) => <ArticleCard key={a.slug} a={a} />)}
      </div>

      <section className="reveal mt-12">
        <div className="mb-5 flex items-end justify-between">
          <h2 className="border-l-4 border-primary pl-3 font-display text-3xl tracking-wide">Anime Suggestions</h2>
          <Link to="/suggestions" className="text-sm font-semibold text-primary">See all →</Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {suggestionCategories.map((c) => (
            <Link key={c.category} to="/suggestions" className="lift rounded-lg border border-border bg-card p-4 hover:border-primary">
              <p className="text-xs font-bold uppercase tracking-widest text-primary">{c.emoji} Best {c.category}</p>
              <p className="mt-1 text-lg font-semibold">{c.best.title}</p>
              <p className="text-sm text-muted-foreground">{c.best.why}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="reveal mt-12">
        <div className="mb-5 flex items-end justify-between">
          <h2 className="border-l-4 border-primary pl-3 font-display text-3xl tracking-wide">Anime List by Category</h2>
          <Link to="/anime-list" className="text-sm font-semibold text-primary">Full list →</Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {animeLists.map((c) => (
            <div key={c.category} className="lift rounded-lg border border-border bg-card p-4 hover:border-primary">
              <p className="text-xs font-bold uppercase tracking-widest text-primary">{c.emoji} {c.category}</p>
              <ol className="mt-2 divide-y divide-border">
                {c.anime.slice(0, 4).map((a, i) => (
                  <li key={a.title} className="flex items-baseline gap-2 py-1.5 text-sm">
                    <span className="font-display text-primary">{i + 1}</span>
                    <span className="font-semibold">{a.title}</span>
                    <span className="ml-auto text-xs text-muted-foreground">{a.year}</span>
                  </li>
                ))}
              </ol>
              <Link to="/anime-list" className="mt-2 inline-block text-xs font-semibold text-primary">All {c.anime.length} in {c.category} →</Link>
            </div>
          ))}
        </div>
      </section>
    </Shell>
  );
}
