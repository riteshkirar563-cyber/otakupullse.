import { pageHead } from "@/lib/site";
import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/Layout";
import { suggestionCategories } from "@/lib/suggestions";

export const Route = createFileRoute("/suggestions")({
  head: () => pageHead("Anime Suggestions — OtakuPulse", "Curated anime recommendations by genre.", "/suggestions"),
  component: Suggestions,
});

function Suggestions() {
  return (
    <Shell>
      <h1 className="font-display text-5xl tracking-wide">Anime <span className="text-primary">Suggestions</span></h1>
      <p className="mt-2 text-muted-foreground">Best anime in every category — and what to watch next.</p>
      <div className="mt-8 grid gap-6 md:grid-cols-2">
        {suggestionCategories.map((c) => (
          <div key={c.category} className="reveal lift rounded-xl border border-border bg-card p-5">
            <h2 className="font-display text-3xl tracking-wide">{c.emoji} {c.category}</h2>
            <div className="mt-4 rounded-lg border border-primary bg-primary/10 p-4">
              <span className="text-xs font-bold uppercase tracking-widest text-primary">🏆 Best in {c.category}</span>
              <h3 className="mt-1 text-xl font-semibold">{c.best.title}</h3>
              <p className="text-sm text-muted-foreground">{c.best.why}</p>
            </div>
            <p className="mt-4 text-xs font-bold uppercase tracking-widest text-accent">You can also watch</p>
            <ul className="mt-2 space-y-2">
              {c.alsoWatch.map((s) => (
                <li key={s.title} className="text-sm"><span className="font-semibold">{s.title}</span> <span className="text-muted-foreground">— {s.why}</span></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Shell>
  );
}
