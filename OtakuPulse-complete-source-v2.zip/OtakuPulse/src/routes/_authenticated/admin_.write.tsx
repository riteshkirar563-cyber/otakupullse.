import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { articleAuthor } from "@/lib/editorial";
import { AdminShell } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { emptyEditor, editorSchema, makeSlug, imageValidation, validatePublication, type EditorValues } from "@/lib/editor-model";
import { pageHead } from "@/lib/site";
import { Save, Eye, Upload, Send, ArrowLeft, History } from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";

export const Route = createFileRoute("/_authenticated/admin_/write")({
  validateSearch: (s: Record<string, unknown>): { inbox?: string | undefined; edit?: string | undefined; workspace?: string | undefined } => ({ inbox: typeof s['inbox'] === 'string' ? s['inbox'] : undefined, edit: typeof s['edit'] === 'string' ? s['edit'] : undefined, workspace: typeof s['workspace'] === 'string' ? s['workspace'] : undefined }),
  head: () => pageHead("Write article — OtakuPulse", "Private manual article editor.", "/admin/write", true),
  component: WritePage,
});
function WritePage() {
  const { user, isAdmin, loading } = useAuth();
  return <AdminShell title="Article editor" subtitle="OtakuPulse / Editorial desk">{loading ? <p>Loading…</p> : !user || !isAdmin ? <p role="alert">Ye page sirf existing site admin ke liye hai.</p> : <Editor userId={user.id} />}</AdminShell>;
}
function Editor({ userId }: { userId: string }) {
  const { inbox, edit, workspace } = Route.useSearch();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [f, setF] = useState<EditorValues>({ ...emptyEditor });
  const [articleId, setArticleId] = useState<string | null>(edit ?? null);
  const [workspaceId, setWorkspaceId] = useState<string | null>(workspace ?? null);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState('');
  const [history, setHistory] = useState<Tables<'article_history'>[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [existingStatus, setExistingStatus] = useState('draft');
  const lastSaved = useRef('');
  const savingRef = useRef(false);
  const workspaceRef = useRef<string | null>(workspace ?? null);
  const valuesRef = useRef(f);
  valuesRef.current = f;

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setReady(false); setError('');
      let values = { ...emptyEditor };
      try {
        if (edit) {
          const result = await supabase.from('news_articles').select('*').eq('id', edit).single();
          if (result.error) throw result.error;
          const a = result.data;
          values = { title: a.title, excerpt: a.excerpt, body: a.body.join('\n\n'), category: a.category === 'manga' ? 'manga' : 'anime', tag: a.tag, author: a.author, slug: a.slug, image: a.image ?? '', image_path: a.image_path, image_alt: a.image_alt ?? '', source: a.source ?? '', source_url: a.source_url ?? '', is_special: a.is_special, seo_title: a.seo_title ?? '', seo_description: a.seo_description ?? '', scheduled_at: a.scheduled_at ?? '' };
          if (a.image_path) { const signed = await supabase.storage.from('article-images').createSignedUrl(a.image_path, 3600); if (signed.error) throw signed.error; values.image = signed.data.signedUrl; }
          if (!cancelled) { setArticleId(a.id); setExistingStatus(a.status); }
        } else if (inbox) {
          const result = await supabase.from('news_inbox').select('*').eq('id', inbox).single();
          if (result.error) throw result.error;
          const i = result.data;
          values = { ...values, title: i.title, slug: makeSlug(i.title), excerpt: i.summary.slice(0, 200), body: i.summary, image: i.image ?? '', source: i.source, source_url: i.source_url };
        }
        if (workspace) {
          const result = await supabase.from('article_workspaces').select('*').eq('id', workspace).single();
          if (result.error) throw result.error;
          const parsed = editorSchema.safeParse(result.data.snapshot);
          if (!parsed.success) throw new Error('Saved workspace could not be read.');
          values = parsed.data;
          if (values.image_path) {
            const signed = await supabase.storage.from('article-images').createSignedUrl(values.image_path, 3600);
            if (signed.error) throw signed.error;
            values.image = signed.data.signedUrl;
          }
          if (result.data.article_id) {
            const current = await supabase.from('news_articles').select('status').eq('id', result.data.article_id).single();
            if (current.error) throw current.error;
            if (!cancelled) setExistingStatus(current.data.status);
          }
          if (!cancelled) setArticleId(result.data.article_id);
        }
        if (!cancelled) { setF(values); lastSaved.current = JSON.stringify(values); setReady(true); }
      } catch (e) { if (!cancelled) setError(e instanceof Error ? e.message : 'Editor could not be loaded.'); }
    };
    void load();
    return () => { cancelled = true; };
  }, [edit, inbox, workspace]);

  const saveWorkspace = async () => {
    if (savingRef.current || !ready) return;
    savingRef.current = true;
    const values = valuesRef.current;
    try {
      editorSchema.parse(values);
      const row = { user_id: userId, article_id: articleId, snapshot: { ...values }, updated_at: new Date().toISOString() };
      const id = workspaceRef.current;
      const result = id ? await supabase.from('article_workspaces').update(row).eq('id', id).select('id').single() : await supabase.from('article_workspaces').insert(row).select('id').single();
      if (result.error) throw result.error;
      workspaceRef.current = result.data.id;
      setWorkspaceId(result.data.id); lastSaved.current = JSON.stringify(values); setSaved(`Workspace saved ${new Date().toLocaleTimeString()}`); setError('');
      await qc.invalidateQueries({ queryKey: ['admin'] });
    } catch (e) { setError(e instanceof Error ? e.message : 'Autosave failed.'); }
    finally { savingRef.current = false; }
  };
  useEffect(() => {
    if (!ready || busy || (!f.title.trim() && !f.body.trim()) || JSON.stringify(f) === lastSaved.current) return;
    const timer = setTimeout(() => { void saveWorkspace(); }, 1500);
    return () => clearTimeout(timer);
  }, [f, ready, busy, workspaceId, articleId]);
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => { if (JSON.stringify(valuesRef.current) !== lastSaved.current) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', warn); return () => window.removeEventListener('beforeunload', warn);
  }, []);

  const update = <K extends keyof EditorValues>(key: K, value: EditorValues[K]) => setF(p => ({ ...p, [key]: value }));
  const saveArticle = async (status: 'draft' | 'published') => {
    if (busy || savingRef.current) { setError('Workspace save chal raha hai. Ek pal baad dobara try karein.'); return; }
    if (status === 'draft' && existingStatus === 'published' && !confirm('Draft save se article public website se hat jayega. Continue?')) return;
    const values = { ...f, slug: f.slug || makeSlug(f.title) };
    try {
      validatePublication(values, status);
      if (status === 'published' && !confirm('Article aur image rights review kar liye? Ab publish karein?')) return;
      setBusy(true); setError('');
      const row = { title: values.title.trim(), excerpt: values.excerpt.trim() || values.body.trim().slice(0, 160), body: values.body.split(/\n\s*\n/).map(p => p.trim()).filter(Boolean), category: values.category, tag: values.tag.trim() || 'News', author: articleAuthor(values.author), slug: values.slug, image: values.image_path ? null : values.image.trim() || null, image_path: values.image_path, image_alt: values.image_alt.trim() || null, source: values.source || null, source_url: values.source_url || null, is_special: status === 'published' && values.is_special, seo_title: values.seo_title.trim() || null, seo_description: values.seo_description.trim() || null, status, scheduled_at: null };
      const result = articleId ? await supabase.from('news_articles').update(row).eq('id', articleId).select('id,slug').single() : await supabase.from('news_articles').insert(row).select('id,slug').single();
      if (result.error) throw result.error;
      setArticleId(result.data.id); setExistingStatus(status); setF(values); lastSaved.current = JSON.stringify(values);
      let warning = '';
      if (inbox && status === 'published') { const marked = await supabase.from('news_inbox').update({ status: 'used' }).eq('id', inbox); if (marked.error) warning = 'Article saved, but inbox status update failed.'; }
      if (workspaceRef.current) { const deleted = await supabase.from('article_workspaces').delete().eq('id', workspaceRef.current); if (deleted.error) warning = 'Article saved, but workspace cleanup failed.'; else { workspaceRef.current = null; setWorkspaceId(null); } }
      await Promise.all([qc.invalidateQueries({ queryKey: ['news'] }), qc.invalidateQueries({ queryKey: ['admin'] })]);
      setSaved(status === 'published' ? 'Article published' : 'Article saved as private draft');
      if (warning) setError(warning);
      else if (status === 'published') await navigate({ to: '/news/$slug', params: { slug: result.data.slug } });
    } catch (e) { setError(e instanceof Error ? e.message : 'Article save failed.'); }
    finally { setBusy(false); }
  };
  const upload = async (file?: File) => {
    if (!file) return;
    const invalid = imageValidation(file); if (invalid) { setError(invalid); return; }
    setBusy(true); setError('');
    const path = `${userId}/${crypto.randomUUID()}.${file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg'}`;
    try {
      const result = await supabase.storage.from('article-images').upload(path, file, { contentType: file.type, upsert: false });
      if (result.error) throw result.error;
      const signed = await supabase.storage.from('article-images').createSignedUrl(path, 3600);
      if (signed.error) throw signed.error;
      setF(p => ({ ...p, image_path: path, image: signed.data.signedUrl }));
    } catch (e) { setError(e instanceof Error ? e.message : 'Image upload failed.'); }
    finally { setBusy(false); }
  };
  const loadHistory = async () => {
    if (!articleId) return;
    const result = await supabase.from('article_history').select('*').eq('article_id', articleId).order('created_at', { ascending: false }).limit(30);
    if (result.error) { setError(result.error.message); return; }
    setHistory(result.data); setShowHistory(p => !p);
  };
  const control = 'w-full rounded-md border border-input bg-background px-3 py-2 text-sm';
  const field = (label: string, key: keyof EditorValues, multiline = false) => <label className="block space-y-2 text-sm font-semibold">{label}{multiline ? <textarea className={`${control} ${key === 'body' ? 'min-h-80 leading-relaxed' : 'min-h-24'}`} value={String(f[key] ?? '')} onChange={e => update(key, e.target.value as never)} /> : <input className={control} value={String(f[key] ?? '')} onChange={e => update(key, e.target.value as never)} />}</label>;
  return <div className="space-y-6"><div className="flex flex-wrap items-center gap-3"><Button asChild variant="ghost"><Link to="/admin" search={{ tab: 'articles' }}><ArrowLeft />Articles</Link></Button><span className="text-sm text-muted-foreground">{existingStatus}</span><span aria-live="polite" className="text-xs text-primary">{saved}</span></div>
    {error && <p role="alert" className="rounded-md border border-destructive p-3 text-sm text-destructive">{error}</p>}
    {!ready ? <p>{error ? 'Article not loaded. Return to Articles to try again.' : 'Loading article…'}</p> : <>
      <div className="flex flex-wrap gap-2"><Button variant="outline" disabled={busy} onClick={() => void saveWorkspace()}><Save />Save workspace</Button><Button variant="outline" disabled={busy} onClick={() => void saveArticle('draft')}><Save />Save draft</Button><Button variant="outline" onClick={() => setPreview(p => !p)}><Eye />{preview ? 'Edit' : 'Preview'}</Button><Button variant="outline" disabled={!articleId} onClick={() => void loadHistory()}><History />History</Button><Button disabled={busy} onClick={() => void saveArticle('published')}><Send />{busy ? 'Saving…' : 'Publish'}</Button></div>
      {showHistory && <ul className="divide-y divide-border">{history.map(h => <li key={h.id} className="py-3 text-sm"><span className="font-semibold">{h.action}</span> · {new Date(h.created_at).toLocaleString()}<details className="mt-2"><summary className="cursor-pointer text-primary">Saved content</summary><pre className="mt-2 max-h-64 overflow-auto whitespace-pre-wrap break-words text-xs">{JSON.stringify(h.snapshot, null, 2)}</pre></details></li>)}</ul>}
      {preview ? <article className="mx-auto max-w-3xl"><p className="text-sm text-accent">Private preview · Not published</p><h1 className="mt-3 font-display text-5xl">{f.title || 'Untitled article'}</h1><p className="mt-3 text-muted-foreground">By {articleAuthor(f.author)}</p>{f.image && <img src={f.image} alt={f.image_alt} className="mt-6 aspect-video w-full rounded-lg object-cover" />}<div className="mt-6 space-y-4 text-lg leading-relaxed">{f.body.split(/\n\s*\n/).map((p, i) => <p key={i}>{p}</p>)}</div></article> : <div className="grid gap-8 xl:grid-cols-[minmax(0,1fr)_320px]"><div className="space-y-5">{field('Title', 'title')}{field('Short summary', 'excerpt', true)}{field('Article body', 'body', true)}{f.source_url && <a className="text-sm text-primary underline" href={f.source_url} target="_blank" rel="noopener noreferrer">Read original source</a>}{field('SEO title', 'seo_title')}{field('SEO description', 'seo_description', true)}<p className="text-xs text-muted-foreground">{f.seo_title.length} title characters · {f.seo_description.length} description characters</p></div><aside className="space-y-5">{field('Slug', 'slug')}<label className="block space-y-2 text-sm font-semibold">Category<select className={control} value={f.category} onChange={e => update('category', e.target.value === 'manga' ? 'manga' : 'anime')}><option value="anime">Anime</option><option value="manga">Manga</option></select></label>{field('Tag', 'tag')}{field('Author', 'author')}{field('Source name', 'source')}{field('Source URL', 'source_url')}<label className="block space-y-2 text-sm font-semibold">Photo URL<input className={control} value={f.image_path ? '' : f.image} placeholder={f.image_path ? 'Uploaded photo selected' : 'https://…'} onChange={e => setF(p => ({ ...p, image: e.target.value, image_path: null }))} /></label><label className="flex cursor-pointer items-center gap-2 text-sm text-primary"><Upload className="size-4" />Upload JPG, PNG or WebP (5 MB max)<input aria-label="Upload cover image" type="file" accept="image/jpeg,image/png,image/webp" disabled={busy} className="sr-only" onChange={e => void upload(e.target.files?.[0])} /></label>{f.image && <img src={f.image} alt={f.image_alt} className="aspect-video w-full rounded-lg object-cover" />}{field('Image description', 'image_alt')}<label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={f.is_special} onChange={e => update('is_special', e.target.checked)} />Today's Special</label><p className="text-xs text-muted-foreground">Publishing is manual. Existing scheduled articles can be converted to a draft or published now; no new automatic schedule is created.</p></aside></div>}
    </>}
  </div>;
}
