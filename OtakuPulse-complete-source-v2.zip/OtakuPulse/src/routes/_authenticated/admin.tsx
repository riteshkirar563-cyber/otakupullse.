import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { AdminShell, type DeskTab } from "@/components/admin/AdminShell";
import { Readiness } from "@/components/admin/Readiness";
import { Button } from "@/components/ui/button";
import { adminDataQuery } from "@/lib/admin-query";
import { filterArticles } from "@/lib/admin-model";
import { isEnglishNews } from "@/lib/editor-model";
import { pageHead } from "@/lib/site";
import { ChevronLeft, ChevronRight, RefreshCw, Star, Pencil, Archive } from "lucide-react";

const tabNames: Record<DeskTab, string> = { overview: "Overview", articles: "Articles", inbox: "News inbox", seo: "SEO health", adsense: "AdSense readiness", analytics: "Analytics" };
export const Route = createFileRoute("/_authenticated/admin")({
  validateSearch: (s: Record<string, unknown>): { tab: DeskTab } => ({ tab: typeof s['tab'] === 'string' && s['tab'] in tabNames ? s['tab'] as DeskTab : 'overview' }),
  head: () => pageHead("Editorial desk — OtakuPulse", "Private article editing and publishing workspace.", "/admin", true),
  component: AdminPage,
});
function AdminPage() {
  const { isAdmin, loading } = useAuth();
  const [tab, setTab] = useState<DeskTab>(Route.useSearch().tab);
  return <AdminShell title={tabNames[tab]} subtitle="OtakuPulse editorial workspace" tab={tab} onTab={setTab}>
    {loading ? <p>Loading…</p> : !isAdmin ? <p role="alert">Ye page sirf existing site admin ke liye hai. Aapke is account par admin access nahi hai.</p> : <Workspace tab={tab} onTab={setTab} />}
  </AdminShell>;
}
function Workspace({ tab, onTab }: { tab: DeskTab; onTab: (t: DeskTab) => void }) {
  const qc = useQueryClient();
  const { data, isPending, error } = useQuery(adminDataQuery);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [category, setCategory] = useState('all');
  const [sort, setSort] = useState('updated');
  const [source, setSource] = useState('all');
  const [page, setPage] = useState(0);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState('');
  const refresh = async () => { await Promise.all([qc.invalidateQueries({ queryKey: ['admin'] }), qc.invalidateQueries({ queryKey: ['news'] })]); };
  const mutate = async (task: () => PromiseLike<{ error: { message: string } | null }>) => {
    setBusy(true); setActionError('');
    try { const result = await task(); if (result.error) throw new Error(result.error.message); await refresh(); }
    catch (e) { setActionError(e instanceof Error ? e.message : 'Action failed'); }
    finally { setBusy(false); }
  };
  if (isPending) return <p>Loading workspace…</p>;
  if (error || !data) return <div role="alert"><p className="text-destructive">{error?.message ?? 'Workspace unavailable'}</p><Button className="mt-4" onClick={refresh}><RefreshCw />Retry</Button></div>;
  const published = data.articles.filter(a => a.status === 'published');
  const fresh = data.inbox.filter(i => i.status === 'new' && isEnglishNews(i.title, i.summary));
  const filtered = filterArticles(data.articles, search, status, category, sort);
  const currentPage = Math.min(page, Math.max(0, Math.ceil(filtered.length / 12) - 1));
  const control = 'min-h-10 rounded-md border border-input bg-background px-3 py-2 text-sm';
  return <div className="space-y-6">{actionError && <p role="alert" className="text-destructive">{actionError}</p>}
    {tab === 'overview' && <>
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">{[['Published articles', published.length], ['Draft articles', data.articles.filter(a => a.status === 'draft').length], ['English inbox', fresh.length], ['Comments', data.comments]].map(([label, value]) => <div key={label} className="rounded-lg border border-border bg-card p-5"><p className="text-sm text-muted-foreground">{label}</p><p className="mt-3 font-display text-4xl">{value}</p></div>)}</div>
      <div className="flex flex-wrap gap-3"><Button onClick={() => onTab('articles')}><Pencil />Manage articles</Button><Button variant="outline" onClick={() => onTab('inbox')}>Review inbox</Button><Button variant="outline" onClick={() => onTab('adsense')}>AdSense checks</Button></div>
      <h2 className="text-xl font-semibold">Saved workspaces</h2><ul className="divide-y divide-border">{data.drafts.map(d => { const snapshot = d.snapshot && typeof d.snapshot === 'object' && !Array.isArray(d.snapshot) ? d.snapshot : {}; return <li key={d.id} className="py-3"><Link to="/admin/write" search={{ workspace: d.id }} className="font-semibold text-primary">{typeof snapshot['title'] === 'string' && snapshot['title'] ? snapshot['title'] : 'Untitled draft'}</Link><p className="mt-1 text-xs text-muted-foreground">{new Date(d.updated_at).toLocaleString()}</p></li>; })}</ul>{!data.drafts.length && <p className="text-sm text-muted-foreground">No saved workspaces.</p>}
    </>}
    {tab === 'articles' && <>
      <div className="flex flex-wrap gap-3"><input aria-label="Search articles" placeholder="Search title, author or slug" className={`${control} flex-1`} value={search} onChange={e => { setSearch(e.target.value); setPage(0); }} /><select aria-label="Article status" className={control} value={status} onChange={e => { setStatus(e.target.value); setPage(0); }}><option value="all">All states</option><option value="published">Published</option><option value="draft">Draft</option><option value="scheduled">Scheduled (legacy)</option></select><select aria-label="Category filter" className={control} value={category} onChange={e => { setCategory(e.target.value); setPage(0); }}><option value="all">All categories</option><option value="anime">Anime</option><option value="manga">Manga</option></select><select aria-label="Sort articles" className={control} value={sort} onChange={e => setSort(e.target.value)}><option value="updated">Recently updated</option><option value="views">Most viewed</option><option value="title">Title A–Z</option></select></div>
      <p className="text-sm text-muted-foreground">{filtered.length} articles</p><ul className="divide-y divide-border">{filtered.slice(currentPage * 12, currentPage * 12 + 12).map(a => <li key={a.id} className="flex flex-wrap items-center gap-3 py-4"><div className="min-w-0 flex-1"><h2 className="font-semibold">{a.title}</h2><p className="mt-1 text-xs text-muted-foreground">{a.status} · {a.category} · {a.views} reading events</p></div>{a.status === 'published' && <Button asChild variant="ghost" size="sm"><Link to="/news/$slug" params={{ slug: a.slug }}>View</Link></Button>}<Button asChild variant="outline" size="sm"><Link to="/admin/write" search={{ edit: a.id }}><Pencil />Edit</Link></Button><Button title="Toggle Today's Special" aria-label={`Toggle special: ${a.title}`} variant={a.is_special ? 'default' : 'ghost'} size="icon" disabled={busy || a.status !== 'published'} onClick={() => mutate(() => supabase.from('news_articles').update({ is_special: !a.is_special }).eq('id', a.id))}><Star /></Button>{a.status !== 'draft' && <Button title="Unpublish to draft" aria-label={`Unpublish: ${a.title}`} variant="ghost" size="icon" disabled={busy} onClick={() => { if (confirm('Is article ko draft banakar public website se hata dein?')) void mutate(() => supabase.from('news_articles').update({ status: 'draft', is_special: false, scheduled_at: null }).eq('id', a.id)); }}><Archive /></Button>}</li>)}</ul>
      {!filtered.length && <p>No articles match these filters.</p>}<div className="flex items-center gap-4"><Button variant="outline" size="icon" aria-label="Previous page" disabled={!currentPage} onClick={() => setPage(currentPage - 1)}><ChevronLeft /></Button><span className="text-sm">Page {currentPage + 1} / {Math.max(1, Math.ceil(filtered.length / 12))}</span><Button variant="outline" size="icon" aria-label="Next page" disabled={(currentPage + 1) * 12 >= filtered.length} onClick={() => setPage(currentPage + 1)}><ChevronRight /></Button></div>
    </>}
    {tab === 'inbox' && <>
      <div className="flex flex-wrap gap-3"><select aria-label="Inbox source" className={control} value={source} onChange={e => setSource(e.target.value)}><option value="all">All sources</option>{[...new Set(data.inbox.map(i => i.source))].map(s => <option key={s}>{s}</option>)}</select><select aria-label="Inbox status" className={control} value={status} onChange={e => setStatus(e.target.value)}><option value="all">All states</option><option value="new">New</option><option value="used">Used</option><option value="dismissed">Dismissed</option></select><Button variant="outline" onClick={refresh}><RefreshCw />Refresh</Button></div>
      <ul className="divide-y divide-border">{data.inbox.filter(i => isEnglishNews(i.title, i.summary) && (source === 'all' || source === i.source) && (status === 'all' || status === i.status)).map(i => <li key={i.id} className="flex gap-4 py-4">{i.image && <img src={i.image} alt="" className="hidden h-20 w-28 rounded object-cover sm:block" />}<div className="min-w-0 flex-1"><p className="text-xs text-primary">{i.source} · {i.status}</p><h2 className="mt-1 font-semibold">{i.title}</h2><p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{i.summary}</p><div className="mt-3 flex flex-wrap gap-2"><Button asChild size="sm"><Link to="/admin/write" search={{ inbox: i.id }}>Write article</Link></Button><Button asChild variant="ghost" size="sm"><a href={i.source_url} target="_blank" rel="noopener noreferrer">Original source</a></Button><Button variant="ghost" size="sm" disabled={busy} onClick={() => mutate(() => supabase.from('news_inbox').update({ status: i.status === 'dismissed' ? 'new' : 'dismissed' }).eq('id', i.id))}>{i.status === 'dismissed' ? 'Restore' : 'Dismiss'}</Button></div></div></li>)}</ul><p className="text-xs text-muted-foreground">Up to 500 inbox entries loaded. English-script filtering does not replace editorial language review.</p>
    </>}
    {(tab === 'seo' || tab === 'adsense') && <Readiness articles={data.articles} mode={tab} />}
    {tab === 'analytics' && <><h2 className="font-display text-4xl">{published.reduce((s, a) => s + a.views, 0)} reading events</h2><p className="text-sm text-muted-foreground">Stored counters, not unique visitors. Revenue, traffic sources and external analytics are unavailable.</p><ol className="divide-y divide-border">{[...published].sort((a, b) => b.views - a.views).slice(0, 10).map(a => <li key={a.id} className="flex justify-between gap-4 py-4"><span>{a.title}</span><span className="shrink-0 font-semibold text-primary">{a.views}</span></li>)}</ol></>}
  </div>;
}
