import { pageHead } from "@/lib/site";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/Layout";
import { animeLists } from "@/lib/animeList";

export const Route = createFileRoute("/anime-list")({
  head: () => pageHead("Anime List by Category — OtakuPulse", "A curated selection of anime across genres.", "/anime-list"),
  component: AnimeListPage,
});

function AnimeListPage() {
  const [active, setActive] = useState<string>("All");
  const shown = active === "All" ? animeLists : animeLists.filter((c) => c.category === active);
  const total = animeLists.reduce((n, c) => n + c.anime.length, 0);

  return (
    <Shell>
      <h1 className="font-display text-5xl tracking-wide">Anime <span className="text-primary">List</span></h1>
      <p className="mt-2 text-muted-foreground">Curated selection — {total} anime across {animeLists.length} categories.</p>

      <div className="mt-6 flex flex-wrap gap-2">
        {["All", ...animeLists.map((c) => c.category)].map((c) => (
          <button
            key={c}
            onClick={() => setActive(c)}
            className={`rounded-full border px-4 py-1.5 font-display text-sm tracking-wide transition-colors ${
              active === c ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:border-primary hover:text-primary"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="mt-8 space-y-8">
        {shown.map((c) => (
          <section key={c.category} className="reveal lift rounded-xl border border-border bg-card p-5">
            <h2 className="font-display text-3xl tracking-wide">
              {c.emoji} {c.category} <span className="text-base font-normal text-muted-foreground">· {c.anime.length} titles</span>
            </h2>
            <ol className="mt-4 divide-y divide-border">
              {c.anime.map((a, i) => (
                <li key={a.title} className="flex items-baseline gap-3 py-3">
                  <span className="font-display text-2xl text-primary">{i + 1}</span>
                  <div>
                    <p className="font-semibold leading-snug">
                      {a.title} <span className="text-xs font-normal text-muted-foreground">({a.year})</span>
                    </p>
                    <p className="text-sm text-muted-foreground">{a.why}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>
        ))}
      </div>
    </Shell>
  );
}
