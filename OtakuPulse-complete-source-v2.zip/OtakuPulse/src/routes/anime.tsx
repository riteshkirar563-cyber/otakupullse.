import { pageHead } from "@/lib/site";
import { createFileRoute } from "@tanstack/react-router";
import { Shell, ArticleCard } from "@/components/Layout";
import { useSuspenseQuery } from "@tanstack/react-query";
import { allNewsQuery } from "@/lib/news-query";

export const Route = createFileRoute("/anime")({
  loader: ({ context }) => context.queryClient.ensureQueryData(allNewsQuery),
  head: () => pageHead("Anime News — OtakuPulse", "Anime announcements, trailers and editorial updates.", "/anime"),
  component: function Page() {
    const { data: articles } = useSuspenseQuery(allNewsQuery);
    return (
    <Shell>
      <h1 className="mb-6 font-display text-5xl tracking-wide">Anime <span className="text-primary">News</span></h1>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {articles.filter((a) => a.category === "anime").map((a) => <ArticleCard key={a.slug} a={a} />)}
      </div>
    </Shell>
    );
  },
});
