export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      article_history: {
        Row: {
          action: string
          actor_id: string | null
          article_id: string | null
          created_at: string
          id: string
          snapshot: Json
        }
        Insert: {
          action: string
          actor_id?: string | null
          article_id?: string | null
          created_at?: string
          id?: string
          snapshot: Json
        }
        Update: {
          action?: string
          actor_id?: string | null
          article_id?: string | null
          created_at?: string
          id?: string
          snapshot?: Json
        }
        Relationships: [
          {
            foreignKeyName: "article_history_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "news_articles"
            referencedColumns: ["id"]
          },
        ]
      }
      article_slug_aliases: {
        Row: {
          article_id: string
          old_slug: string
        }
        Insert: {
          article_id: string
          old_slug: string
        }
        Update: {
          article_id?: string
          old_slug?: string
        }
        Relationships: [
          {
            foreignKeyName: "article_slug_aliases_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "news_articles"
            referencedColumns: ["id"]
          },
        ]
      }
      article_workspaces: {
        Row: {
          article_id: string | null
          id: string
          snapshot: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          article_id?: string | null
          id?: string
          snapshot?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          article_id?: string | null
          id?: string
          snapshot?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "article_workspaces_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "news_articles"
            referencedColumns: ["id"]
          },
        ]
      }
      comments: {
        Row: {
          article_slug: string
          body: string
          created_at: string
          id: string
          user_id: string
          user_name: string
        }
        Insert: {
          article_slug: string
          body: string
          created_at?: string
          id?: string
          user_id: string
          user_name: string
        }
        Update: {
          article_slug?: string
          body?: string
          created_at?: string
          id?: string
          user_id?: string
          user_name?: string
        }
        Relationships: []
      }
      news_articles: {
        Row: {
          author: string
          body: string[]
          category: string
          created_at: string
          excerpt: string
          id: string
          image: string | null
          image_alt: string | null
          image_path: string | null
          is_special: boolean
          published_at: string
          scheduled_at: string | null
          seo_description: string | null
          seo_title: string | null
          slug: string
          source: string | null
          source_url: string | null
          status: string
          tag: string
          title: string
          updated_at: string
          views: number
        }
        Insert: {
          author?: string
          body?: string[]
          category?: string
          created_at?: string
          excerpt: string
          id?: string
          image?: string | null
          image_alt?: string | null
          image_path?: string | null
          is_special?: boolean
          published_at?: string
          scheduled_at?: string | null
          seo_description?: string | null
          seo_title?: string | null
          slug: string
          source?: string | null
          source_url?: string | null
          status?: string
          tag?: string
          title: string
          updated_at?: string
          views?: number
        }
        Update: {
          author?: string
          body?: string[]
          category?: string
          created_at?: string
          excerpt?: string
          id?: string
          image?: string | null
          image_alt?: string | null
          image_path?: string | null
          is_special?: boolean
          published_at?: string
          scheduled_at?: string | null
          seo_description?: string | null
          seo_title?: string | null
          slug?: string
          source?: string | null
          source_url?: string | null
          status?: string
          tag?: string
          title?: string
          updated_at?: string
          views?: number
        }
        Relationships: []
      }
      news_inbox: {
        Row: {
          created_at: string
          id: string
          image: string | null
          published_at: string
          source: string
          source_url: string
          status: string
          summary: string
          title: string
        }
        Insert: {
          created_at?: string
          id?: string
          image?: string | null
          published_at?: string
          source: string
          source_url: string
          status?: string
          summary?: string
          title: string
        }
        Update: {
          created_at?: string
          id?: string
          image?: string | null
          published_at?: string
          source?: string
          source_url?: string
          status?: string
          summary?: string
          title?: string
        }
        Relationships: []
      }
      news_job_state: {
        Row: {
          id: string
          last_error: string | null
          last_run_at: string | null
          locked_until: string | null
          paused_reason: string | null
        }
        Insert: {
          id: string
          last_error?: string | null
          last_run_at?: string | null
          locked_until?: string | null
          paused_reason?: string | null
        }
        Update: {
          id?: string
          last_error?: string | null
          last_run_at?: string | null
          locked_until?: string | null
          paused_reason?: string | null
        }
        Relationships: []
      }
      releases: {
        Row: {
          created_at: string
          id: string
          kind: string
          note: string
          release_date: string
          title: string
        }
        Insert: {
          created_at?: string
          id?: string
          kind?: string
          note?: string
          release_date: string
          title: string
        }
        Update: {
          created_at?: string
          id?: string
          kind?: string
          note?: string
          release_date?: string
          title?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      increment_article_views: { Args: { _slug: string }; Returns: undefined }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
