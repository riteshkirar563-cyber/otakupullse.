<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- News flow: an hourly managed schedule calls /api/public/jobs/fetch-news, which only stores RSS items in the private news_inbox table; articles are written and published by an admin from /admin (prefilled from the inbox) into news_articles. Pages merge those with static articles in src/lib/news.ts via src/lib/news-query.ts. Why: the owner wants every published story written by hand.
- Admin access: the first account to sign in gets the admin role (user_roles + has_role); writes rely on RLS from the browser client. Why: one-owner site, no server write layer needed.
- Editor author defaults and blank-author fallback share src/lib/editorial.ts; loaded existing authors remain unchanged. Why: keep new-article defaults consistent without rewriting historical attribution.
- Editorial desk uses existing RLS-protected article/workspace/history tables and browser writes; workspace autosave does not publish. Why: preserve owner-only manual publishing and recover unfinished work.
- AdSense verification uses a head meta tag and ads.txt; ad execution remains disabled until consent setup is complete. Why: verify ownership without pre-consent advertising requests.
- Legacy static stories retain their URLs but are marked unverified and noindexed; public queries prefer live records. Why: preserve links without presenting sample claims as verified news.
- Public news data and uploaded images use anonymous RLS reads through server-only helpers; sitemap handlers never call server-function RPC wrappers. Why: preserve draft privacy and avoid nested RPC failures after deployment.
