# OtakuPulse — complete source delivery

This archive contains the current updated application source, assets, package lockfile, tests, configuration and database migration files. It is not a database backup: existing articles, accounts, roles and uploaded storage objects remain in your existing Lovable Cloud project. Private environment files, credentials, dependencies, Git metadata and generated build output are excluded.

## Local setup
1. Extract the archive and install Bun.
2. Run `bun install`, then `bun run dev`.
3. Configure the original project environment through your own secure environment settings. The browser integration requires `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY` and `VITE_SUPABASE_PROJECT_ID`; obtain the original project configuration securely, do not publish private credentials. Server-side environment and managed authentication/schedule bindings must also remain configured.
4. The generated route tree is recreated by the application tooling.

## Deployment
The existing Lovable project is the simplest deployment path: review the latest preview and use Publish in Lovable when ready. This ZIP does not publish changes automatically. An independent deployment must support TanStack Start and the Cloudflare Worker runtime; configure the existing cloud integration, authentication redirects, storage access and hourly inbox schedule in that environment. Do not deploy this as a static-only website.

## Existing backend
Migration files are included for reference. The editor additions were already applied to the existing project; do not blindly rerun migrations or change admin roles. No new database migration is required merely to download or use this source with the existing project. Do not replace or reset existing data.

## Verification and remaining work
The latest automated preview build reported success. Existing-admin browser checks confirmed dashboard access, the default author “Otaku pulse”, image upload, workspace save, preview and private draft save. Full publishing/unpublishing/deletion, comments, login/logout and permissions checks have not all been completed. The last anonymous draft/history browser check was interrupted, so those checks are not claimed as passed. Some requested editor actions and deeper SEO/security checks still need completion. The task roadmap is included and retains outstanding work.

About, Privacy, Terms and editorial policy pages and the /index redirect are included. Contact details are deferred. AdSense publisher verification metadata and ads.txt use the existing publisher ID; ad serving stays disabled pending consent setup. Google alone decides verification and approval: publishing the latest code and completing the Google review are still manual steps.
