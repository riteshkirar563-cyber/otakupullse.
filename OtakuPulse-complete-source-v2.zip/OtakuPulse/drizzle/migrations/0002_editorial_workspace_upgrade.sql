ALTER TABLE public.news_articles ADD COLUMN status text NOT NULL DEFAULT 'published', ADD COLUMN scheduled_at timestamptz, ADD COLUMN seo_title text, ADD COLUMN seo_description text, ADD COLUMN image_alt text, ADD COLUMN image_path text, ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.news_articles ALTER COLUMN author SET DEFAULT 'Otaku pulse';
ALTER TABLE public.news_articles ADD CONSTRAINT article_status_valid CHECK (status IN ('draft','published','scheduled'));
CREATE INDEX news_articles_visibility_idx ON public.news_articles(status, scheduled_at);
ALTER POLICY "Anyone can read news" ON public.news_articles USING (status = 'published' OR (status = 'scheduled' AND scheduled_at <= now()));
CREATE POLICY "Admins read all article states" ON public.news_articles FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE TABLE public.article_workspaces (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, article_id uuid REFERENCES public.news_articles(id) ON DELETE SET NULL, snapshot jsonb NOT NULL DEFAULT '{}'::jsonb, updated_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT, INSERT, UPDATE, DELETE ON public.article_workspaces TO authenticated;
GRANT ALL ON public.article_workspaces TO service_role;
ALTER TABLE public.article_workspaces ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage own workspaces" ON public.article_workspaces FOR ALL TO authenticated USING (user_id = auth.uid() AND public.has_role(auth.uid(), 'admin')) WITH CHECK (user_id = auth.uid() AND public.has_role(auth.uid(), 'admin'));
CREATE TABLE public.article_history (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), article_id uuid REFERENCES public.news_articles(id) ON DELETE SET NULL, actor_id uuid, action text NOT NULL, snapshot jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT ON public.article_history TO authenticated;
GRANT ALL ON public.article_history TO service_role;
ALTER TABLE public.article_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read article history" ON public.article_history FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE TABLE public.article_slug_aliases (old_slug text PRIMARY KEY, article_id uuid NOT NULL REFERENCES public.news_articles(id) ON DELETE CASCADE);
GRANT SELECT ON public.article_slug_aliases TO anon, authenticated;
GRANT ALL ON public.article_slug_aliases TO service_role;
ALTER TABLE public.article_slug_aliases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Visible article aliases" ON public.article_slug_aliases FOR SELECT TO anon, authenticated USING (EXISTS (SELECT 1 FROM public.news_articles a WHERE a.id=article_id));
CREATE OR REPLACE FUNCTION public.audit_article_changes() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
 IF TG_OP='DELETE' THEN
  INSERT INTO public.article_history(article_id,actor_id,action,snapshot) VALUES (NULL,auth.uid(),'deleted',to_jsonb(OLD));
  RETURN OLD;
 END IF;
 IF TG_OP='UPDATE' AND NEW.slug IS DISTINCT FROM OLD.slug THEN
  IF EXISTS (SELECT 1 FROM public.article_slug_aliases WHERE old_slug=NEW.slug AND article_id<>NEW.id) THEN RAISE EXCEPTION 'Slug already reserved by another article'; END IF;
  INSERT INTO public.article_slug_aliases(old_slug,article_id) VALUES(OLD.slug,NEW.id) ON CONFLICT(old_slug) DO NOTHING;
  UPDATE public.comments SET article_slug=NEW.slug WHERE article_slug=OLD.slug;
 END IF;
 IF TG_OP='UPDATE' AND (to_jsonb(NEW)-'views'-'updated_at') IS NOT DISTINCT FROM (to_jsonb(OLD)-'views'-'updated_at') THEN RETURN NEW; END IF;
 NEW.updated_at=now();
 INSERT INTO public.article_history(article_id,actor_id,action,snapshot) VALUES (NEW.id,auth.uid(),CASE WHEN TG_OP='INSERT' THEN 'created' ELSE 'updated' END,to_jsonb(NEW));
 RETURN NEW;
END $$;
CREATE TRIGGER article_history_after AFTER INSERT OR UPDATE OR DELETE ON public.news_articles FOR EACH ROW EXECUTE FUNCTION public.audit_article_changes();
REVOKE ALL ON FUNCTION public.audit_article_changes() FROM PUBLIC, anon, authenticated;
CREATE OR REPLACE FUNCTION public.validate_article_edit() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
BEGIN
 NEW.updated_at=now();
 IF length(NEW.title)>250 OR length(NEW.slug)>200 OR NEW.slug !~ '^[a-z0-9]+(-[a-z0-9]+)*$' THEN RAISE EXCEPTION 'Invalid title or article slug'; END IF;
 IF NEW.status='scheduled' AND NEW.scheduled_at IS NULL THEN RAISE EXCEPTION 'Scheduled publication requires a date'; END IF;
 IF NEW.status<>'draft' AND (length(trim(NEW.title))=0 OR cardinality(NEW.body)=0) THEN RAISE EXCEPTION 'Title and article body are required for publication'; END IF;
 IF EXISTS (SELECT 1 FROM public.article_slug_aliases WHERE old_slug=NEW.slug AND article_id<>NEW.id) THEN RAISE EXCEPTION 'Slug already reserved'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER validate_article_before BEFORE INSERT OR UPDATE ON public.news_articles FOR EACH ROW EXECUTE FUNCTION public.validate_article_edit();
CREATE OR REPLACE FUNCTION public.increment_article_views(_slug text) RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path=public AS $$ UPDATE public.news_articles SET views=views+1 WHERE slug=_slug AND (status='published' OR (status='scheduled' AND scheduled_at<=now())); $$;
REVOKE ALL ON FUNCTION public.handle_first_admin() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
CREATE POLICY "Admins upload article images" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id='article-images' AND public.has_role(auth.uid(),'admin') AND (storage.foldername(name))[1]=auth.uid()::text);
CREATE POLICY "Admins manage article images" ON storage.objects FOR SELECT TO authenticated USING (bucket_id='article-images' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY "Readers access published article images" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id='article-images' AND EXISTS (SELECT 1 FROM public.news_articles a WHERE a.image_path=name AND (a.status='published' OR (a.status='scheduled' AND a.scheduled_at<=now()))));
CREATE POLICY "Admins delete own article images" ON storage.objects FOR DELETE TO authenticated USING (bucket_id='article-images' AND public.has_role(auth.uid(),'admin') AND (storage.foldername(name))[1]=auth.uid()::text);