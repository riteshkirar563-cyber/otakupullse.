CREATE TABLE public.news_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  source_url text NOT NULL UNIQUE,
  source text NOT NULL,
  title text NOT NULL,
  excerpt text NOT NULL,
  body text[] NOT NULL DEFAULT '{}',
  category text NOT NULL DEFAULT 'anime',
  tag text NOT NULL DEFAULT 'News',
  image text,
  published_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.news_articles TO anon, authenticated;
GRANT ALL ON public.news_articles TO service_role;
ALTER TABLE public.news_articles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read news" ON public.news_articles FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX news_articles_published_idx ON public.news_articles (published_at DESC);

CREATE TABLE public.news_job_state (
  id text PRIMARY KEY,
  locked_until timestamptz,
  paused_reason text,
  last_run_at timestamptz,
  last_error text
);
GRANT ALL ON public.news_job_state TO service_role;
ALTER TABLE public.news_job_state ENABLE ROW LEVEL SECURITY;
INSERT INTO public.news_job_state (id) VALUES ('fetch-news');