-- Roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own roles" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- The very first person to sign in becomes the site admin
CREATE OR REPLACE FUNCTION public.handle_first_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created_first_admin AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_first_admin();

-- Articles: manual publishing, special, views
ALTER TABLE public.news_articles ADD COLUMN is_special boolean NOT NULL DEFAULT false;
ALTER TABLE public.news_articles ADD COLUMN views integer NOT NULL DEFAULT 0;
ALTER TABLE public.news_articles ADD COLUMN author text NOT NULL DEFAULT 'Ritesh Kirar';
ALTER TABLE public.news_articles ALTER COLUMN source_url DROP NOT NULL;
ALTER TABLE public.news_articles ALTER COLUMN source DROP NOT NULL;
GRANT INSERT, UPDATE, DELETE ON public.news_articles TO authenticated;
CREATE POLICY "Admins insert news" ON public.news_articles FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update news" ON public.news_articles FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete news" ON public.news_articles FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.increment_article_views(_slug text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  UPDATE public.news_articles SET views = views + 1 WHERE slug = _slug;
$$;
GRANT EXECUTE ON FUNCTION public.increment_article_views(text) TO anon, authenticated;

-- Inbox of news collected from other sites (never public)
CREATE TABLE public.news_inbox (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source text NOT NULL,
  source_url text NOT NULL UNIQUE,
  title text NOT NULL,
  summary text NOT NULL DEFAULT '',
  image text,
  published_at timestamptz NOT NULL DEFAULT now(),
  status text NOT NULL DEFAULT 'new',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE, DELETE ON public.news_inbox TO authenticated;
GRANT ALL ON public.news_inbox TO service_role;
ALTER TABLE public.news_inbox ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read inbox" ON public.news_inbox FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update inbox" ON public.news_inbox FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete inbox" ON public.news_inbox FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE INDEX news_inbox_published_idx ON public.news_inbox (published_at DESC);

-- Comments
CREATE TABLE public.comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  article_slug text NOT NULL,
  user_id uuid NOT NULL,
  user_name text NOT NULL,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 1000),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.comments TO anon;
GRANT SELECT, INSERT, DELETE ON public.comments TO authenticated;
GRANT ALL ON public.comments TO service_role;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads comments" ON public.comments FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Users post own comments" ON public.comments FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Owner or admin deletes comment" ON public.comments FOR DELETE TO authenticated USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE INDEX comments_slug_idx ON public.comments (article_slug, created_at);

-- Release calendar
CREATE TABLE public.releases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  release_date date NOT NULL,
  kind text NOT NULL DEFAULT 'TV',
  note text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.releases TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.releases TO authenticated;
GRANT ALL ON public.releases TO service_role;
ALTER TABLE public.releases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads releases" ON public.releases FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Admins insert releases" ON public.releases FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update releases" ON public.releases FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete releases" ON public.releases FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

INSERT INTO public.releases (title, release_date, kind, note) VALUES
  ('Murciélago', '2027-01-08', 'TV', 'Winter 2027 premiere on Tokyo MX'),
  ('Ghost: Yoru no Hate', '2027-02-11', 'Movie', 'Japanese theatrical release');